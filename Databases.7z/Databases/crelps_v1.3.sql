use crelps_real_db;

/*VERSION 1.3*/

------------------------------------------karuna 23-05-2019-----------------------------------------------------------------------------

INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('User', 1, 1, '/user');

INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Owner', 1, 4, '/user/owner')
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Broker', 1, 4, '/user/broker');

UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'Listings' WHERE (`menu_id` = '1');
UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'Listings' WHERE (`menu_id` = '2');
UPDATE `crelps_real_db`.`menus` SET `menu_url` = '/listings' WHERE (`menu_id` = 1);
UPDATE `crelps_real_db`.`menus` SET `menu_url` = '/listings' WHERE (`menu_id` = 2);

UPDATE `crelps_real_db`.`sub_menus` SET `sub_menu_name` = 'Active' WHERE (`sub_menu_id` = 3);
UPDATE `crelps_real_db`.`sub_menus` SET `sub_menu_name` = 'Draft' WHERE (`sub_menu_id` = 4);
UPDATE `crelps_real_db`.`sub_menus` SET `menu_url` = '/listings/sale' WHERE (`sub_menu_id` = 1);
UPDATE `crelps_real_db`.`sub_menus` SET `menu_url` = '/listings/lease' WHERE (`sub_menu_id` = 2);
UPDATE `crelps_real_db`.`sub_menus` SET `menu_url` = '/listings/active' WHERE (`sub_menu_id` = 3);
UPDATE `crelps_real_db`.`sub_menus` SET `menu_url` = '/listings/draft' WHERE (`sub_menu_id` = 4);

INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('Billing', 2, 1, '/billing');
INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('Billing', 3, 1, '/billing');
---------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------karuna 23-05-2019------------------------------------------------------------
CREATE TABLE `crelps_real_db`.`user_billing` (
  `billing_id` INT(11) NOT NULL AUTO_INCREMENT,
  `card_no` VARCHAR(255) NULL,
  `card_name` VARCHAR(255) NULL,
  `valid_thru_date` VARCHAR(255) NULL,
  `cvv_no` VARCHAR(255) NULL,
  `card_holder_name` VARCHAR(255) NULL,
  `address_one` VARCHAR(255) NULL,
  `address_two` VARCHAR(255) NULL,
  `city` VARCHAR(255) NULL,
  `state` VARCHAR(255) NULL,k
  `country` VARCHAR(255) NULL,
  `zip_code` VARCHAR(255) NULL,
  `phone` VARCHAR(255) NULL,
  `user_id` INT(11) NULL,
  PRIMARY KEY (`billing_id`));

----------------------------------------------------------------------------------------------------------------------------------------
  
------------------------------------------Varun 24-05-2019-----------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`property_attachement` 
ADD COLUMN `attachement_description` VARCHAR(255) NULL AFTER `attachement_path`;
-------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------Varun 28-05-2019-----------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`property_attachement` 
CHANGE COLUMN `attachement_description` `attachement_description` TEXT NULL DEFAULT NULL ;
-------------------------------------------------------------------------------------------------------------------------------------
UPDATE `crelps_real_db`.`roles` SET `role` = 'ADMIN', `description` = 'ADMIN' WHERE (`role_id` = '1');
-------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------karuna 05-06-2019------------------------------------------------------------------------------
UPDATE `crelps_real_db`.`property_types` SET `type_name` = 'Investment Sale' WHERE (`type_id` = '7');

UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Retail' WHERE (`sub_type_id` = '30');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Office' WHERE (`sub_type_id` = '31');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Industrial' WHERE (`sub_type_id` = '32');

INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Multi-family', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Hospitality', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Self Storage', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Land', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Marina', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Cannabis', 1, 7);
---------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------karuna 06-06-2019-----------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `company_name_one` VARCHAR(255) NULL AFTER `contact_email_two`;

ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `company_name_two` VARCHAR(255) NULL AFTER `company_name_one`;
-----------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------karuna 07-06-2019---------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`property_types` 
ADD COLUMN `property_status` VARCHAR(255) NULL AFTER `status`;

UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale' WHERE (`type_id` = '7');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '2');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '3');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '4');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '5');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '6');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '8');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '9');

----------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------karuna 10-06-2019------------------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `thumbnail_company_logo_path` VARCHAR(255) NULL AFTER `thumbnail_image_path`;

ALTER TABLE `crelps_real_db`.`user_details` 
ADD COLUMN `thumbnail_company_logo_path` VARCHAR(255) NULL AFTER `company_logo_path`;

ALTER TABLE `crelps_real_db`.`property_types` 
CHANGE COLUMN `status` `status` BIT(1) NOT NULL ;

------------------------------------------------karuna 12-06-2019-----------------------------------------------------------------------------------------

UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'User', `menu_url` = '/user' WHERE (`menu_id` = '3');
UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'Setting', `menu_url` = '/settings' WHERE (`menu_id` = '4');


UPDATE `crelps_real_db`.`sub_menus` SET `menu_id` = '3' WHERE (`sub_menu_id` = '5');
UPDATE `crelps_real_db`.`sub_menus` SET `menu_id` = '3' WHERE (`sub_menu_id` = '6');


UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'User', `menu_url` = '/user' WHERE (`menu_id` = '3');
UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'Setting', `menu_url` = '/settings' WHERE (`menu_id` = '4');

UPDATE `crelps_real_db`.`menus` SET `role_id` = '1' WHERE (`menu_id` = '4');

----------------------------------------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------karuna 14-06-2019--------------------------------------------------------------------------------------------------------
CREATE TABLE `crelps_real_db`.`state` (
  `state_id` INT(11) NOT NULL AUTO_INCREMENT,
  `state_name` VARCHAR(255) NULL,
  `state_code` VARCHAR(255) NULL,
  `status` BIT(1) NOT NULL,
  PRIMARY KEY (`state_id`));
  
ALTER TABLE  crelps_real_db.properties
ADD state_id char AFTER user_id;


  ----------------------------------------------------------------------------------------------------------------------------------------------------------
