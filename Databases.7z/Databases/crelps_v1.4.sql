use crelps_real_db;

/*VERSION 1.4*/

--------------------------------------------karuna 05-06-2019------------------------------------------------------------------------------
UPDATE `crelps_real_db`.`property_types` SET `type_name` = 'Investment Sale' WHERE (`type_id` = '7');

UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Retail' WHERE (`sub_type_id` = '30');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Office' WHERE (`sub_type_id` = '31');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Industrial' WHERE (`sub_type_id` = '32');

INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Multi-family', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Hospitality', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Self Storage', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Land', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Marina', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Cannabis', 1, 7);
---------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------karuna 06-06-2019-----------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `company_name_one` VARCHAR(255) NULL AFTER `contact_email_two`;

ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `company_name_two` VARCHAR(255) NULL AFTER `company_name_one`;
-----------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------karuna 07-06-2019---------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`property_types` 
ADD COLUMN `property_status` VARCHAR(255) NULL AFTER `status`;

UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale' WHERE (`type_id` = '7');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '2');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '3');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '4');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '5');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '6');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '8');
UPDATE `crelps_real_db`.`property_types` SET `property_status` = 'sale,lease' WHERE (`type_id` = '9');

----------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------karuna 10-06-2019------------------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `thumbnail_company_logo_path` VARCHAR(255) NULL AFTER `thumbnail_image_path`;

ALTER TABLE `crelps_real_db`.`user_details` 
ADD COLUMN `thumbnail_company_logo_path` VARCHAR(255) NULL AFTER `company_logo_path`;

ALTER TABLE `crelps_real_db`.`property_types` 
CHANGE COLUMN `status` `status` BIT(1) NOT NULL ;

------------------------------------------------karuna 12-06-2019-----------------------------------------------------------------------------------------

UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'User', `menu_url` = '/user' WHERE (`menu_id` = '3');
UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'Setting', `menu_url` = '/settings' WHERE (`menu_id` = '4');


UPDATE `crelps_real_db`.`sub_menus` SET `menu_id` = '3' WHERE (`sub_menu_id` = '5');
UPDATE `crelps_real_db`.`sub_menus` SET `menu_id` = '3' WHERE (`sub_menu_id` = '6');


UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'User', `menu_url` = '/user' WHERE (`menu_id` = '3');
UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'Setting', `menu_url` = '/settings' WHERE (`menu_id` = '4');

UPDATE `crelps_real_db`.`menus` SET `role_id` = '1' WHERE (`menu_id` = '4');

----------------------------------------------------------------------------------------------------------------------------------------------------------------

