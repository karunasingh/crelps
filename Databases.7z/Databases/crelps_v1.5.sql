use crelps_real_db;

/*VERSION 1.5*/

CREATE DEFINER=`root`@`%` PROCEDURE `getDetailedSearchProperties`(IN propertyStatus varchar(45),
IN address varchar(255),
IN searchCity varchar(100),
IN searchState varchar(100),
IN searchZipcode varchar(100),
IN searchTenancy varchar(20),
IN minCapRate int(20),
IN maxCapRate int(20),
IN minLotSize int(20),
IN maxLotSize int(20),
IN minSalePrice int(20),
IN maxSalePrice int(20),
IN minYearBuilt int(20),
IN maxYearBuilt int(20),
IN subTypeId varchar(100),
IN minBuildingSize int(20),
IN maxBuildingSize int(20))
BEGIN
SET @query = CONCAT("SELECT * FROM properties INNER JOIN property_details ON properties.property_id = property_details.property_id WHERE
    CASE
		WHEN ",address != ''," THEN `address_one` like CONCAT('%", address, "%')
			ELSE 1=1
			END
			AND
   CASE
		WHEN ",searchCity != ''," THEN `city` like CONCAT('%", searchCity, "%')
		ELSE 1 = 1 
	  END
      AND
      CASE
		WHEN ",searchState != ''," THEN `state` like CONCAT('%", searchState, "%')
		ELSE 1 = 1 
	  END
      AND
      CASE
		WHEN ",searchZipcode != ''," THEN `zip_code` = '",searchZipcode,"'
		ELSE 1 = 1 
	  END
      AND
		CASE
			WHEN ",propertyStatus != 'saleAndLease'," THEN `property_status` = '",propertyStatus,"'
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", minSalePrice != 0," THEN `price` >= ",minSalePrice,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", maxSalePrice != 0," THEN `price` <= ",maxSalePrice,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", minCapRate != 0," THEN `cap_rate` >= ",minCapRate,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", maxCapRate != 0," THEN `cap_rate` <= ",maxCapRate,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", minYearBuilt != 0," THEN `year_built` >= ",minYearBuilt,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", maxYearBuilt != 0," THEN `year_built` <= ",maxYearBuilt,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", minBuildingSize != 0," THEN `building_size` >= ",minBuildingSize,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", maxBuildingSize != 0," THEN `building_size` <= ",maxBuildingSize,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", minLotSize != 0," THEN `lot_size` >= ",minLotSize,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", maxLotSize != 0," THEN `lot_size` <= ",maxLotSize,"
			ELSE 1 = 1 
			END
		AND
        CASE
			WHEN ", searchTenancy != ''," THEN `tenancy` = '",searchTenancy,"'
			ELSE 1 = 1 
			END
		AND
    CASE 
		WHEN ",subTypeId = '0'," THEN 1 = 1
		WHEN ",subTypeId != ''," THEN `sub_type_id` IN (",subTypeId,")
        ELSE 1 = 1
	  END
    ");
  PREPARE stmt FROM @query;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
END
----------------------------------------------------------------------------------------------------------------------------------------

----------------------------------------------karuna 14-06-2019--------------------------------------------------------------------------------------------------------
CREATE TABLE `crelps_real_db`.`state` (
  `state_id` INT(11) NOT NULL AUTO_INCREMENT,
  `state_name` VARCHAR(255) NULL,
  `state_code` VARCHAR(255) NULL,
  `status` BIT(1) NOT NULL,
  PRIMARY KEY (`state_id`));
  
ALTER TABLE  crelps_real_db.properties
ADD state_id char AFTER user_id;


  ----------------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------karuna 15-06-2019------------------------------------------------------------------------------
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Alabama - AL', 01, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Alaska - AK', 02, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Arizona - AZ', 03, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Arkansas - AR', 04, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('California - CA', 05, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Colorado - CO', 06, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Connecticut - CT', 07, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Delaware - DE', 08, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Florida - FL', 09, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Georgia - GA', 10, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Hawaii - HI', 11, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Idaho - IDE', 12, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Illinois - IL', 13, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Indiana - IN', 14, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Iowa - IA', 15, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Kansas - KS', 16, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Kentucky - KY', 17, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Louisiana - LA', 18, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Maine - ME', 19, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Maryland - MD', 20, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Massachusetts - MA', 21, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Michigan - MI', 22, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Minnesota - MN', 23, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Mississippi - MS', 24, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Missouri - MO', 25, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Montana - MT', 26, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Nebraska - NE', 27, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Nevada - NV', 28, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('New Hampshire - NH', 29, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('New Jersey - NJ', 30, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('New Mexico - NM', 31, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('New York - NY', 32, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('North Carolina - NC', 33, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('North Dakota - ND', 34, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Ohio - OH', 35, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Oklahoma - OK', 36, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Oregon - OR', 37, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Pennsylvania - PA', 38, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Rhode Island - RI', 39, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('South Carolina - SC', 40, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('South Dakota - SD', 41, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Tennessee - TN', 42, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Texas - TX', 43, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Utah - UT', 44, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Vermont - VT', 45, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Virginia - VA', 46, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Washington - WA', 47, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('West Virginia - WV', 48, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Wisconsin - WI', 49, 1);
INSERT INTO `crelps_real_db`.`state` (`state_name`, `state_code`, `status`) VALUES ('Wyoming - WY', 50, 1);
-----------------------------------------------------------------------------------------------------------------------------------------

-----------------------------------karuna 20-06-2019---------------------------------------------------------------------------
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Medical', 1, 7);
------------------------
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Medical' WHERE (`sub_type_id` = '32');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Industrial' WHERE (`sub_type_id` = '46');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Multi-family' WHERE (`sub_type_id` = '47');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Hospitality' WHERE (`sub_type_id` = '48');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Self Storage' WHERE (`sub_type_id` = '49');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Land' WHERE (`sub_type_id` = '50');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Marina' WHERE (`sub_type_id` = '51');
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Cannabis' WHERE (`sub_type_id` = '52');

------------------------------------------------------------------------------------------------------------------------