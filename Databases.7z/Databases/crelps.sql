use crelps_real_db;

CREATE TABLE `crelps_real_db`.`menus` (
  `menu_id` INT NOT NULL AUTO_INCREMENT,
  `menu_name` VARCHAR(100) NULL,
  `role_id` INT NULL,
  `status` BIT(1) NOT NULL,
  PRIMARY KEY (`menu_id`));
  
  CREATE TABLE `crelps_real_db`.`sub_menus` (
  `sub_menu_id` INT NOT NULL AUTO_INCREMENT,
  `sub_menu_name` VARCHAR(100) NULL,
  `status` BIT(1) NULL,
  `menu_id` INT NULL,
  PRIMARY KEY (`sub_menu_id`));
  
  
  CREATE TABLE `crelps_real_db`.`user_details` (
  `user_detail_id` INT NOT NULL AUTO_INCREMENT,
  `phone_number` VARCHAR(45) NULL,
  `profile_pic_name` VARCHAR(100) NULL,
  `profile_pic_path` VARCHAR(200) NULL,
  `company_name` VARCHAR(75) NULL,
  `company_logo_name` VARCHAR(100) NULL,
  `company_logo_path` VARCHAR(200) NULL,
  `user_id` INT NULL,
  `created_by` INT NULL,
  `created_date` TIMESTAMP NULL,
  `modified_by` INT NULL,
  `modified_date` DATETIME NULL,
  PRIMARY KEY (`userDetailId`));
  
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE `crelps_real_db`.`user_companies`;
SET FOREIGN_KEY_CHECKS = 1;

ALTER TABLE `crelps_real_db`.`properties` 
DROP FOREIGN KEY `FK5pqnwwtampyhlrcf3b7ls0gs0`;
ALTER TABLE `crelps_real_db`.`properties` 
DROP COLUMN `company_id`,
DROP INDEX `FK5pqnwwtampyhlrcf3b7ls0gs0` ;
;

ALTER TABLE `crelps_real_db`.`menus` 
ADD COLUMN `menu_url` VARCHAR(100) NULL AFTER `status`;

ALTER TABLE `crelps_real_db`.`sub_menus` 
ADD COLUMN `menu_url` VARCHAR(100) NULL AFTER `menu_id`;

----------------04-04-2019 karuna----------------------
ALTER TABLE `crelps_real_db`.`property_sub_types` 
DROP COLUMN `property_type_id`;
--------------------------------------------------------


----------------06-04-2019 karuna----------------------
INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('Property', 2, 1, '/property');
INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('Property', 3, 1, '/property');

INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Sale', 1, 1, '/property?type=sale');
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Lease', 1, 1, '/property?type=lease');
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Post Listing', 1, 1, '/property?status=post-listing');
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Draft Property', 1, 1, '/property?status=save-as-draft');

INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Sale', 1, 2, '/property?type=sale');
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Lease', 1, 2, '/property?type=lease');
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Post Listing', 1, 2, '/property?status=post-listing');
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Draft Property', 1, 2, '/property?status=save-as-draft');

---------------------------------------------------------------------------------------------------------------------------------------------------------------

----------------------------06-04-2019 karuna----------------------property_types------------------------------------------------------------------------
INSERT INTO `crelps_real_db`.`property_types` (`type_id`, `type_name`, `status`) VALUES ('1', 'City', 1);
INSERT INTO `crelps_real_db`.`property_types` (`type_id`, `type_name`, `status`) VALUES ('2', 'Retail', 1);
INSERT INTO `crelps_real_db`.`property_types` (`type_id`, `type_name`, `status`) VALUES ('3', 'Office', 1);
INSERT INTO `crelps_real_db`.`property_types` (`type_id`, `type_name`, `status`) VALUES ('4', 'Industrial', 1);
INSERT INTO `crelps_real_db`.`property_types` (`type_id`, `type_name`, `status`) VALUES ('5', 'Hospitality', 1);
INSERT INTO `crelps_real_db`.`property_types` (`type_id`, `type_name`, `status`) VALUES ('6', 'Multi-Family', 1);
INSERT INTO `crelps_real_db`.`property_types` (`type_id`, `type_name`, `status`) VALUES ('7', 'Investment Sales', 1);
INSERT INTO `crelps_real_db`.`property_types` (`type_id`, `type_name`, `status`) VALUES ('8', 'Land', 1);
INSERT INTO `crelps_real_db`.`property_types` (`type_id`, `type_name`, `status`) VALUES ('9', 'Specialty', 1);
----------------------------------------------------------------------------------------------------------------------------------

----------------------------06-05-2019 karuna--------------property_sub_types-------------------------------------------------------------
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('1', 'United States', 1, 1);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('1', 'Restaurant', 1, 2);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('3', 'Shopping Center', 1, 2);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('4', 'Bank', 1, 2);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('5', 'Gas', 1, 2);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('6', 'Drugstore', 1, 2);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('7', 'Grocery/Convenience Store', 1, 2);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('8', 'Daycare', 1, 2);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('9', 'Freestanding', 1, 2);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('10', 'Strip center', 1, 2);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('11', 'Medical', 1, 3);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('12', 'High-rise', 1, 3);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('13', 'Multi-Tenant', 1, 3);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('14', 'Loft/Creative', 1, 3);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('15', 'Office/Retail', 1, 3);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('16', 'Office/Residential', 1, 3);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('17', 'Warehouse', 1, 4);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('18', 'Flex', 1, 4);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('19', 'Distribution', 1, 4);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('20', 'Manufacturing', 1, 4);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('21', 'Truck Terminal', 1, 4);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('22', 'R&D', 1, 4);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('23', 'Motel', 1, 5);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('24', 'Hotel', 1, 5);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('25', 'Garden', 1, 6);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('26', 'Low-rise', 1, 6);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('27', 'Mid-rise', 1, 6);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('28', 'High-rise', 1, 6);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('29', 'Mobile Home Parks', 1, 6);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('30', 'Income producing', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('31', 'Net Lease', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('32', 'NNN', 1, 7);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('33', 'Commercial,', 1, 8);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('34', 'Industrial', 1, 8);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('35', 'Agricultural', 1, 8);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('36', 'Residential', 1, 8);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('37', 'Multifamily', 1, 8);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('38', 'Self-storage', 1, 9);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('39', 'Sports', 1, 9);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('40', 'Religious', 1, 9);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('41', 'School', 1, 9);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('42', 'Marina', 1, 9);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('43', 'Auto', 1, 9);
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_id`, `sub_type_name`, `status`, `type_id`) VALUES ('44', 'Cannabis', 1, 9);
-------------------------------------------------------------------------------------------------------------------------------------------------

----------------------------06-05-2019 karuna--------alter property-------------------------------------------------------------------------

ALTER TABLE  crelps_real_db.properties
ADD price VARCHAR(255) AFTER property_name;

ALTER TABLE  crelps_real_db.properties
ADD building_size VARCHAR(255) AFTER price;

ALTER TABLE  crelps_real_db.properties
ADD lot_size VARCHAR(255) AFTER building_size;

ALTER TABLE  crelps_real_db.properties
ADD year_built VARCHAR(255) AFTER lot_size;

ALTER TABLE  crelps_real_db.properties
ADD no_of_stories VARCHAR(255) AFTER year_built;

ALTER TABLE  crelps_real_db.properties
ADD zoning VARCHAR(255) AFTER no_of_stories ;

ALTER TABLE  crelps_real_db.properties
ADD space_available VARCHAR(255) AFTER zoning;

ALTER TABLE  crelps_real_db.properties
ADD tenancy VARCHAR(255) AFTER space_available;

ALTER TABLE  crelps_real_db.properties
ADD noi VARCHAR(255) AFTER tenancy  ;

ALTER TABLE  crelps_real_db.properties
ADD cap_rate VARCHAR(255) AFTER noi;

ALTER TABLE  crelps_real_db.properties
ADD sale_type VARCHAR(255) AFTER cap_rate;

ALTER TABLE  crelps_real_db.properties
ADD property_status VARCHAR(255) AFTER sale_type;

ALTER TABLE  crelps_real_db.properties
ADD area VARCHAR(255) AFTER property_status;
----------------------------------------------------------------------------------------------------------------------------------------

------------------08-04-2019 karuna-----------------------------------------------------------------
ALTER TABLE  crelps_real_db.properties
ADD publish_property VARCHAR(255) AFTER area;
--------------------------------------------------------------------------------------------------

------------------09-04-2019 karuna------------create photo_gallary------------------------------------------------------------------------------------------
CREATE TABLE `crelps_real_db`.`property_gallery` (
  `gallery_id` INT(11) NOT NULL,
  `originel_image_name` VARCHAR(255) NULL,
  `image_path` VARCHAR(255) NULL,
  `status` BIT(1) NULL,
  `default_image` BIT(1) NULL,
  `property_id` INT(11) NULL,
  PRIMARY KEY (`gallery_id`));

----------------------------------------------------------------------------------------------------------------------------------------

------------------11-04-2019 Varun------------sub_menus------------------------------------------------------------------------------------------  
  INSERT INTO `sub_menus` VALUES (1,'Sale',_binary '',1,'properties/sale'),(2,'Lease',_binary '',1,'properties/lease'),(3,'Post Listing',_binary '',1,'properties/PostListing'),(4,'Draft Property',_binary '',1,'properties/SaveAsDraft');
  ----------------------------------------------------------------------------------------------------------------------------------------
  
----------------16-04-2019 Varun--------------------------------------------------------------------------------------------------------
INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('Property', 2, 1, '/properties');
INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('Property', 3, 1, '/properties');

INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Sale', 1, 1, '/properties/sale');
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Lease', 1, 1, '/properties/lease');
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Post Listing', 1, 1, '/properties/active');
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Draft Property', 1, 1, '/properties/draft');
----------------------------------------------------------------------------------------------------------------------------------------------



-------------------------12-04-2019 karuna ----------------------------------------------------------------------------------------
  CREATE TABLE `crelps_real_db`.`property_details` (
  `property_detail_id` INT(11) NOT NULL AUTO_INCREMENT,
  `building_size` VARCHAR(255) NULL,
  `sale_type` VARCHAR(255) NULL,
  `lot_size` VARCHAR(255) NULL,
  `year_built` VARCHAR(255) NULL,
  `no_of_stories` VARCHAR(255) NULL,
  `zoning` VARCHAR(255) NULL,
  `space_available` VARCHAR(255) NULL,
  `tenancy` VARCHAR(255) NULL,
  `noi` VARCHAR(255) NULL,
  `area` VARCHAR(255) NULL,
  `description` LONGTEXT NULL DEFAULT NULL,
  PRIMARY KEY (`property_detail_id`));
  
  ALTER TABLE `crelps_real_db`.`property_details` 
ADD COLUMN `property_id` INT(11) NULL AFTER `description`;

CREATE TABLE `crelps_real_db`.`property_attachement` (
  `attachement_id` INT NOT NULL AUTO_INCREMENT,
  `originel_attachement_name` VARCHAR(45) NULL,
  `attachement_path` VARCHAR(45) NULL,
  `status` BIT(1) NULL,
  `default_attachement` BIT(1) NULL,
  `property_id` INT(11) NULL,
  `created_date` TIMESTAMP NULL,
  `created_by` INT(11) NULL,
  `modified_date` DATETIME NULL,
  `modified_by` INT(11) NULL,
  PRIMARY KEY (`attachement_id`));
  
  CREATE TABLE `crelps_real_db`.`properties` (
  `property_id` INT(11) NOT NULL AUTO_INCREMENT,
  `property_name` VARCHAR(45) NULL,
  `address_one` VARCHAR(45) NULL,
  `address_two` VARCHAR(45) NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(45) NULL,
  `zip_code` VARCHAR(45) NULL,
  `status` BIT(1) NULL,
  `publish_property` VARCHAR(45) NULL,
  `property_status` VARCHAR(45) NULL,
  `user_id` INT(11) NULL,
  `type_id` INT(11) NULL,
  `sub_type_id` VARCHAR(100) NULL,
  `created_date` TIMESTAMP NULL,
  `created_by` INT(11) NULL,
  `modified_date` DATETIME NULL,
  `modified_by` INT(11) NULL,
  PRIMARY KEY (`property_id`));
  
 ALTER TABLE  crelps_real_db.properties
ADD contact_name VARCHAR(255) AFTER property_status;
ALTER TABLE  crelps_real_db.properties
ADD contact_email VARCHAR(255) AFTER contact_name;
ALTER TABLE  crelps_real_db.properties
ADD contact_image_path VARCHAR(255) AFTER contact_name;
ALTER TABLE  crelps_real_db.properties
ADD phone VARCHAR(255) AFTER contact_image_path;
  ------------------------------------------------------17-04-2019-----------------------------------------------------------------------------

-------------------------23-04-2019 Varun ----------------------------------------------------------------------------------------
CREATE TABLE `property_attachement` (
  `attachement_id` int(11) NOT NULL AUTO_INCREMENT,
  `originel_attachement_name` varchar(255) DEFAULT NULL,
  `attachement_path` varchar(255) DEFAULT NULL,
  `status` bit(1) NOT NULL,
  `default_attachement` bit(1) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`attachement_id`),
  KEY `FKk7x2gcp788ihdgn16gj4p5i94` (`property_id`),
  CONSTRAINT `FKk7x2gcp788ihdgn16gj4p5i94` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `property_gallery` (
  `gallery_id` int(11) NOT NULL AUTO_INCREMENT,
  `default_image` bit(1) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `originel_image_name` varchar(255) DEFAULT NULL,
  `status` bit(1) NOT NULL,
  `property_id` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`gallery_id`),
  KEY `FK98l3wap5i350eut8o4yub02ag` (`property_id`),
  CONSTRAINT `FK98l3wap5i350eut8o4yub02ag` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-------------------------------------------------------------------------------------------------------------------------------------------


-----------------------24-04-2019----------------------
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `default_image_path` VARCHAR(255) NULL AFTER `price`;

ALTER TABLE `crelps_real_db`.`properties` 
CHANGE COLUMN `publish_property` `publish_property` BIT(1) NULL DEFAULT NULL ;


-------------------------26-04-2019 Varun -----------------------------------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `latitude` VARCHAR(45) NULL AFTER `price`;
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `longitude` VARCHAR(45) NULL AFTER `latitude`;
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `contact_email` VARCHAR(45) NULL AFTER `phone`;
---------------------------------------------------------------------------------------------------------------------------------------

-------------------------02-05-2019 Varun -----------------------------------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`property_attachement` 
DROP COLUMN `default_attachement`;
---------------------------------------------------------------------------------------------------------------------------------------

-------------------------04-05-2019 Varun -----------------------------------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`properties` 
CHANGE COLUMN `city` `city` VARCHAR(100) NULL DEFAULT NULL ,
CHANGE COLUMN `state` `state` VARCHAR(100) NULL DEFAULT NULL ,
CHANGE COLUMN `zip_code` `zip_code` VARCHAR(10) NULL DEFAULT NULL ;
---------------------------------------------------------------------------------------------------------------------------------------

-------------------------06-05-2019 Varun -----------------------------------------------------------------------------------------------------
CREATE DEFINER=`root`@`localhost` PROCEDURE `getProperties`(IN propertyType int(11), IN propertyStatus varchar(45), IN address varchar(255))
BEGIN  
IF(propertyStatus = 'saleAndLease') then
                if(propertyType > 0 && address != '') then
                                SELECT * FROM properties WHERE publish_property = 1 AND status = 1 AND type_id = propertyType AND (`address_one` like CONCAT('%', address , '%') || `address_two` like CONCAT('%', address , '%') || `city` like CONCAT('%', address , '%') || `state` like CONCAT('%', address , '%') || `zip_code` like CONCAT('%', address , '%'));
    elseif(propertyType > 0) then
                                SELECT * FROM properties WHERE publish_property = 1 AND status = 1 AND type_id = propertyType;
                elseif(address != '') then
                                SELECT * FROM properties WHERE publish_property = 1 AND status = 1 AND (`address_one` like CONCAT('%', address , '%') || `address_two` like CONCAT('%', address , '%') || `city` like CONCAT('%', address , '%') || `state` like CONCAT('%', address , '%') || `zip_code` like CONCAT('%', address , '%'));
                else
                                SELECT * FROM properties WHERE publish_property = 1 AND status = 1;
                end if;
end if;
    
if(propertyStatus = 'sale' || propertyStatus = 'lease') then
                if(propertyType > 0 && address != '') then
                                SELECT * FROM properties WHERE publish_property = 1 AND status = 1 AND property_status = propertyStatus AND (`address_one` like CONCAT('%', address , '%') || `address_two` like CONCAT('%', address , '%') || `city` like CONCAT('%', address , '%') || `state` like CONCAT('%', address , '%') || `zip_code` like CONCAT('%', address , '%'));
                elseif(propertyType > 0) then
                                SELECT * FROM properties WHERE publish_property = 1 AND status = 1 AND property_status = propertyStatus AND type_id = propertyType;
                elseif(address != '') then
                                SELECT * FROM properties WHERE publish_property = 1 AND status = 1 AND property_status = propertyStatus AND (`address_one` like CONCAT('%', address , '%') || `address_two` like CONCAT('%', address , '%') || `city` like CONCAT('%', address , '%') || `state` like CONCAT('%', address , '%') || `zip_code` like CONCAT('%', address , '%'));
                else
                                SELECT * FROM properties WHERE publish_property = 1 AND status = 1 AND property_status = propertyStatus;
                end if;
end if;
END
---------------------------------------------------------------------------------------------------------------------------------------

--------------------------------karuna 07-05-2019-------------------------------------------------------------------------------------------------
DELETE FROM `crelps_real_db`.`property_types` WHERE (`type_id` = '1');

DELETE FROM `crelps_real_db`.`property_sub_types` WHERE (`sub_type_id` = '1');
UPDATE `crelps_real_db`.`property_types` SET `status` = '0' WHERE (`type_id` = '1');

--------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------karuna 10-05-2019------------------------------------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `lease_price_type` VARCHAR(100) NULL AFTER `price`;
---------------------------------------------------------------------------------------------------------------------------------------

-----------------------------------------------KARUNA 13-05-2019-------------------------------------------------------------------------
INSERT INTO `crelps_real_db`.`property_sub_types` (`sub_type_name`, `status`, `type_id`) VALUES ('Co-working/Shared', 1, 3);
---------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------karuna 15-05-2019--------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `contact_name_two` VARCHAR(100) NULL AFTER `contact_name`;

ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `phone_two` VARCHAR(100) NULL AFTER `contact_name_two`;

ALTER TABLE `crelps_real_db`.`properties` 
ADD COLUMN `contact_email_two` VARCHAR(100) NULL AFTER `phone_two`;
-------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------Varun 18-05-2019--------------------------------------------------------------------------
UPDATE `crelps_real_db`.`property_sub_types` SET `sub_type_name` = 'Commercial' WHERE (`sub_type_id` = '33');
-------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------Varun 20-05-2019--------------------------------------------------------------------------
ALTER TABLE `crelps_real_db`.`user_details` 
DROP COLUMN `profile_pic_path`,
DROP COLUMN `profile_pic_name`;
-------------------------------------------------------------------------------------------------------------------------------------------------


-----------------------------karuna 20-05-2019---------------------------------------------------------------------------------------------------------
INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('Setting', 1, 1, '/settings');

CREATE TABLE `crelps_real_db`.`settings` (
  `settings_id` INT(11) NOT NULL AUTO_INCREMENT,
  `price_per_property` VARCHAR(255) NULL,
  `promotional` BIT(1) NULL,
  PRIMARY KEY (`settings_id`));
---------------------------------------------------------------------------------------------------------------------------------------------------------
  
  ----------------------------------------karuna 21-05-2019----------------------------------------------------------------------------------
INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('User', 1, 1, '/user');
  ----------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------karuna 23-05-2019-----------------------------------------------------------------------------
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Owner', 1, 4, '/user/owner')
INSERT INTO `crelps_real_db`.`sub_menus` (`sub_menu_name`, `status`, `menu_id`, `menu_url`) VALUES ('Broker', 1, 4, '/user/broker');

UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'Listings' WHERE (`menu_id` = '1');
UPDATE `crelps_real_db`.`menus` SET `menu_name` = 'Listings' WHERE (`menu_id` = '2');
UPDATE `crelps_real_db`.`menus` SET `menu_url` = '/listings' WHERE (`menu_id` = 1);
UPDATE `crelps_real_db`.`menus` SET `menu_url` = '/listings' WHERE (`menu_id` = 2);

UPDATE `crelps_real_db`.`sub_menus` SET `sub_menu_name` = 'Active' WHERE (`sub_menu_id` = 3);
UPDATE `crelps_real_db`.`sub_menus` SET `sub_menu_name` = 'Draft' WHERE (`sub_menu_id` = 4);
UPDATE `crelps_real_db`.`sub_menus` SET `menu_url` = '/listings/sale' WHERE (`sub_menu_id` = 1);
UPDATE `crelps_real_db`.`sub_menus` SET `menu_url` = '/listings/lease' WHERE (`sub_menu_id` = 2);
UPDATE `crelps_real_db`.`sub_menus` SET `menu_url` = '/listings/active' WHERE (`sub_menu_id` = 3);
UPDATE `crelps_real_db`.`sub_menus` SET `menu_url` = '/listings/draft' WHERE (`sub_menu_id` = 4);

INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('Billing', 2, 1, '/billing');
INSERT INTO `crelps_real_db`.`menus` (`menu_name`, `role_id`, `status`, `menu_url`) VALUES ('Billing', 3, 1, '/billing');
-------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------karuna 23-05-2019------------------------------------------------------------
CREATE TABLE `crelps_real_db`.`user_billing` (
  `billing_id` INT(11) NOT NULL AUTO_INCREMENT,
  `card_no` VARCHAR(255) NULL,
  `card_name` VARCHAR(255) NULL,
  `valid_thru_date` DATE NULL,
  `cvv_no` VARCHAR(255) NULL,
  `card_holder_name` VARCHAR(255) NULL,
  `address_one` VARCHAR(255) NULL,
  `address_two` VARCHAR(255) NULL,
  `city` VARCHAR(255) NULL,
  `state` VARCHAR(255) NULL,
  `country` VARCHAR(255) NULL,
  `zip_code` VARCHAR(255) NULL,
  `phone` VARCHAR(255) NULL,
  `user_id` INT(11) NULL,
  PRIMARY KEY (`billing_id`));

----------------------------------------------------------------------------------------------------------------------------------------
  
  