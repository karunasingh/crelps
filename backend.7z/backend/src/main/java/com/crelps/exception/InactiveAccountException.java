package com.crelps.exception;

import javax.naming.AuthenticationException;
/**
 * 
 * @author varunb
 *
 */
public class InactiveAccountException extends AuthenticationException{


	private static final long serialVersionUID = 1L;
/**
 * 
 * @param Exception: If status is inactive or email id id is not verified
 * 
 * @author varunb
 */
	public InactiveAccountException(String msg) {
		super(msg);
	}
	
}
