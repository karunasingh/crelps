package com.crelps.exception;

import javax.naming.AuthenticationException;

public class UserDoesNotExistException extends AuthenticationException{
	/**
	 * 
	 * @author varunb
	 *
	 */
	private static final long serialVersionUID = 1L;
/**
 * 
 * @param Exception: If User isn't registered with the application
 * 
 * @author varunb
 */
	public UserDoesNotExistException(String msg) {
		super(msg);
	}
	
}
