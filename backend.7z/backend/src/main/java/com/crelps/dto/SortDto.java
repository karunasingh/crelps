package com.crelps.dto;

public class SortDto {
	
	private String propertyStatus;
	private String sortType;
	private String sortCategory;
	private int pageNo;
	private int userId;
	private int maxElements;

	public String getPropertyStatus() {
		return propertyStatus;
	}
	public void setPropertyStatus(String propertyStatus) {
		this.propertyStatus = propertyStatus;
	}
	public String getSortType() {
		return sortType;
	}
	public void setSortType(String sortType) {
		this.sortType = sortType;
	}
	public String getSortCategory() {
		return sortCategory;
	}
	public void setSortCategory(String sortCategory) {
		this.sortCategory = sortCategory;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getMaxElements() {
		return maxElements;
	}
	public void setMaxElements(int maxElements) {
		this.maxElements = maxElements;
	}
	
	
}
