/**
 * 
 */
package com.crelps.dto;

import java.util.List;

import com.crelps.model.SubMenu;

/**
 * Class Information - This class is user for set the meues and submenus values
 * 
 * @author KarunaS
 * @version 1.0 - 28-March-2019
 */
public class MenuDto {

    private int menuId;

    private String menuName;
    
    private String menuUrl;

    private boolean status;

    private List<SubMenu> subMenuList;

    public int getMenuId() {
        return menuId;
    }

    public void setMenuId(int menuId) {
        this.menuId = menuId;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public List<SubMenu> getSubMenuList() {
        return subMenuList;
    }

    public void setSubMenuList(List<SubMenu> subMenuList) {
        this.subMenuList = subMenuList;
    }
    
    public String getMenuUrl() {
		return menuUrl;
	}

	public void setMenuUrl(String menuUrl) {
		this.menuUrl = menuUrl;
	}

	@Override
    public String toString() {
        return "MenuDto{" + "menuId=" + menuId + ", menuName='" + menuName + '\'' + ", status='" + status + '\''
            + ", subMenuList='" + subMenuList + '\''

            + '}';

    }
}
