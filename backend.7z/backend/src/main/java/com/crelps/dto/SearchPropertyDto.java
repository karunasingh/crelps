/**
 * 
 */
package com.crelps.dto;

/**
 * @author KarunaS
 *
 */
public class SearchPropertyDto {

	 public String propertyTypeId;
	 public String propertyStatus;
	 public String  searchFieldVal;
	 public String city; 
	 public int state;
	 public String zipcode;
	 public String spaceUse; 
	 public String tenancy;
	 public int minCapRate; 
	 public int maxCapRate; 
	 public int minLotSize;
	 public int maxLotSize; 
	 public int minSalePrice; 
	 public int maxSalePrice;
	 public int minLeasePrice; 
	 public int maxLeasePrice;
	 public int minYearBuilt; 
	 public int maxYearBuilt;
	 public int minBuildingSize;
	 public int maxBuildingSize;
	 public String subTypeId;
	public int getMinAvailableSpace() {
		return minAvailableSpace;
	}
	public void setMinAvailableSpace(int minAvailableSpace) {
		this.minAvailableSpace = minAvailableSpace;
	}
	public int minAvailableSpace;
	public int maxAvailableSpace;
	 
	public int getMaxAvailableSpace() {
		return maxAvailableSpace;
	}
	public void setMaxAvailableSpace(int maxAvailableSpace) {
		this.maxAvailableSpace = maxAvailableSpace;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getPropertyTypeId() {
		return propertyTypeId;
	}
	public void setPropertyTypeId(String propertyTypeId) {
		this.propertyTypeId = propertyTypeId;
	}
	public String getSpaceUse() {
		return spaceUse;
	}
	public void setSpaceUse(String spaceUse) {
		this.spaceUse = spaceUse;
	}
	public String getTenancy() {
		return tenancy;
	}
	public void setTenancy(String tenancy) {
		this.tenancy = tenancy;
	}

	public String getSubTypeId() {
		return subTypeId;
	}
	public void setSubTypeId(String subTypeId) {
		this.subTypeId = subTypeId;
	}
	
	public String getPropertyStatus() {
		return propertyStatus;
	}
	public void setPropertyStatus(String propertyStatus) {
		this.propertyStatus = propertyStatus;
	}
	public String getSearchFieldVal() {
		return searchFieldVal;
	}
	public void setSearchFieldVal(String searchFieldVal) {
		this.searchFieldVal = searchFieldVal;
	}
	public int getMinCapRate() {
		return minCapRate;
	}
	public void setMinCapRate(int minCapRate) {
		this.minCapRate = minCapRate;
	}
	public int getMaxCapRate() {
		return maxCapRate;
	}
	public void setMaxCapRate(int maxCapRate) {
		this.maxCapRate = maxCapRate;
	}
	public int getMinLotSize() {
		return minLotSize;
	}
	public void setMinLotSize(int minLotSize) {
		this.minLotSize = minLotSize;
	}
	public int getMaxLotSize() {
		return maxLotSize;
	}
	public void setMaxLotSize(int maxLotSize) {
		this.maxLotSize = maxLotSize;
	}
	public int getMinSalePrice() {
		return minSalePrice;
	}
	public void setMinSalePrice(int minSalePrice) {
		this.minSalePrice = minSalePrice;
	}
	public int getMaxSalePrice() {
		return maxSalePrice;
	}
	public void setMaxSalePrice(int maxSalePrice) {
		this.maxSalePrice = maxSalePrice;
	}
	public int getMinLeasePrice() {
		return minLeasePrice;
	}
	public void setMinLeasePrice(int minLeasePrice) {
		this.minLeasePrice = minLeasePrice;
	}
	public int getMaxLeasePrice() {
		return maxLeasePrice;
	}
	public void setMaxLeasePrice(int maxLeasePrice) {
		this.maxLeasePrice = maxLeasePrice;
	}
	public int getMinYearBuilt() {
		return minYearBuilt;
	}
	public void setMinYearBuilt(int minYearBuilt) {
		this.minYearBuilt = minYearBuilt;
	}
	public int getMaxYearBuilt() {
		return maxYearBuilt;
	}
	public void setMaxYearBuilt(int maxYearBuilt) {
		this.maxYearBuilt = maxYearBuilt;
	}
	public int getMinBuildingSize() {
		return minBuildingSize;
	}
	public void setMinBuildingSize(int minBuildingSize) {
		this.minBuildingSize = minBuildingSize;
	}
	public int getMaxBuildingSize() {
		return maxBuildingSize;
	}
	public void setMaxBuildingSize(int maxBuildingSize) {
		this.maxBuildingSize = maxBuildingSize;
	}

	 
	 
}
