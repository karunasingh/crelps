package com.crelps.dto;

import java.util.List;
import com.crelps.model.Property;
import com.crelps.model.User;
/**
 * Class Information - This class is used for set the response
 * 
 * @author VarunB
 * @version 1.0 - 20-March-2019
 */
public class UserCompanyDto {

	
	private int companyId;
	
	private String companyName;
	
	private String companyDescription;
	
	private String companyUrl;
	
	private User user;
	
	private boolean status;
	
	private String createdDate;
	
	private int createdBy;

	private String modifiedDate;

	private int modifiedBy;
	
	private List<Property> property;
	
	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}

	public String getCompanyUrl() {
		return companyUrl;
	}

	public void setCompanyUrl(String companyUrl) {
		this.companyUrl = companyUrl;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public List<Property> getProperty() {
		return property;
	}

	public void setProperty(List<Property> property) {
		this.property = property;
	}
    @Override
    public String toString() {
        return "UserCompanyDto{" +
            "userCompanyId=" + companyId + ", userCompanyName='" + companyName + '\'' + 
               ", userCompanyDescription='" + companyDescription + '\''+
                 ", userCompanyUrl='" + companyUrl + '\''+
               ", createdBy='" + createdBy + '\''
             +", createdDate='" + createdDate + '\'' 
            +  ", modifiedBy='" + modifiedBy + '\''+
               ", status='" + status + '\''
               +", userId='"+ user + '\''
             + '}';
    }

}
