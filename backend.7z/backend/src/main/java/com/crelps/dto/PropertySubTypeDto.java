/**
 * 
 */
package com.crelps.dto;

/**
 * Class Information - This class is Controller the properties
 * @author KarunaS
 * @version 1.0 - 04-April-2019
 */
public class PropertySubTypeDto {
    

    private int subTypeId;
    
    private String subTypeName;
    
    private boolean status;

    public int getSubTypeId() {
        return subTypeId;
    }

    public void setSubTypeId(int subTypeId) {
        this.subTypeId = subTypeId;
    }

    public String getSubTypeName() {
        return subTypeName;
    }

    public void setSubTypeName(String subTypeName) {
        this.subTypeName = subTypeName;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    

}
