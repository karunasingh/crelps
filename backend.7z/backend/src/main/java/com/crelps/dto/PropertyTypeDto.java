/**
 * 
 */
package com.crelps.dto;

import java.util.List;

import com.crelps.model.PropertySubType;

/**
 * Class Information - This class is save the property type
 * @author KarunaS
 * @version 1.0 - 03-April-2019
 */
public class PropertyTypeDto {

    private int typeId;
    
    private String typeName;
    
    private boolean status;
    
    private String propertyStatus;
    
    private List<PropertySubType> propertySubType;  

    public int getTypeId() {
        return typeId;
    }

    public void setTypeId(int typeId) {
        this.typeId = typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getPropertyStatus() {
        return propertyStatus;
    }

    public void setPropertyStatus(String propertyStatus) {
        this.propertyStatus = propertyStatus;
    }

	public List<PropertySubType> getPropertySubType() {
		return propertySubType;
	}

	public void setPropertySubType(List<PropertySubType> propertySubType) {
		this.propertySubType = propertySubType;
	}

    
}
