/**
 * ===========================================================================
 * File Name ApiResponse.java
 *
 * Created on 12-March-2019
 *
 * This code contains copyright information which is the proprietary property
 * of crelps. No part of this code may be reproduced, stored or transmitted
 * in any form without the prior written permission of crelps.
 *
 * Copyright (C) crelps. 2019
 * All rights reserved.
 *
 * Modification history:
 * $Log: ApiResponse.java,v $
 * ===========================================================================
 */
package com.crelps.dto;

import org.springframework.http.HttpStatus;
/**
 * Class Information - This class is used for set the response
 * 
 * @author VarunB
 * @version 1.0 - 14-March-2019
 */
public class ApiResponse {
	
	private int status;
	private String message;
	private Object result;

	public ApiResponse(HttpStatus status, String message, Object result){
	    this.status = status.value();
	    this.message = message;
	    this.result = result;
    }

    public ApiResponse(HttpStatus status, String message){
        this.status = status.value();
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    @Override
	public String toString() {
		return "ApiResponse [statusCode=" + status + ", message=" + message +"]";
	}


}
