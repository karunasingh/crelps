package com.crelps.dto;
public interface UserDTOTest {

    int getUserId();

    String getFirstName();

    String getLastName();

    String getUsername();

   

}