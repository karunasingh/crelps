package com.crelps.dto;

import com.crelps.model.Property;

/**
 * Class Information - This class is to get the property details
 * 
 * @author varunb
 * @version 1.0 - 01-May-2019
 */
public class SavePropertyDto {

	private Property property;
	private String defaultImageName;
	private String editImage;
	private String editAttachment;
	private int galleryId;

	public Property getProperty() {
		return property;
	}

	public void setProperty(Property property) {
		this.property = property;
	}

	public String getDefaultImageName() {
		return defaultImageName;
	}

	public void setDefaultImageName(String defaultImageName) {
		this.defaultImageName = defaultImageName;
	}

	public String getEditImage() {
		return editImage;
	}

	public void setEditImage(String editImage) {
		this.editImage = editImage;
	}

	public String getEditAttachment() {
		return editAttachment;
	}

	public void setEditAttachment(String editAttachment) {
		this.editAttachment = editAttachment;
	}

	public int getGalleryId() {
		return galleryId;
	}

	public void setGalleryId(int galleryId) {
		this.galleryId = galleryId;
	}


}
