/**
 * 
 */
package com.crelps.dto;

/**
 * @author karunas
 *
 */
public class UserSortDto {
   // private String propertyStatus;
    private String sortType;
    private String sortCategory;
    private int pageNo;
    private int roleId;
    private int userId;
    private int maxElements;
    private String role;
    //private Role roles;


//    public String getPropertyStatus() {
//        return propertyStatus;
//    }
//
//    public void setPropertyStatus(String propertyStatus) {
//        this.propertyStatus = propertyStatus;
//    }

    
    public String getSortType() {
        return sortType;
    }

    public String getRole() {
        return role;
    }

 /*   public Role getRoles() {
        return roles;
    }

    public void setRoles(Role roles) {
        this.roles = roles;
    }*/

    public void setRole(String role) {
        this.role = role;
    }

    public void setSortType(String sortType) {
        this.sortType = sortType;
    }

    public String getSortCategory() {
        return sortCategory;
    }

    public void setSortCategory(String sortCategory) {
        this.sortCategory = sortCategory;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }


    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public int getMaxElements() {
        return maxElements;
    }

    public void setMaxElements(int maxElements) {
        this.maxElements = maxElements;
    }


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    
}
