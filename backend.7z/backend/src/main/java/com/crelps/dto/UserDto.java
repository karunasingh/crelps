/**
 * ===========================================================================
 * File Name UserDto.java
 *
 * Created on 12-March-2019
 *
 * This code contains copyright information which is the proprietary property
 * of crelps. No part of this code may be reproduced, stored or transmitted
 * in any form without the prior written permission of crelps.
 *
 * Copyright (C) crelps. 2019
 * All rights reserved.
 *
 * Modification history:
 * $Log: UserDto.java,v $
 * ===========================================================================
 */
package com.crelps.dto;

import java.util.Date;

import com.crelps.model.Role;
import com.crelps.model.UserDetails;

/**
 * Class Information - This class used for transfer the object
 *
 * @author KarunaS
 * @version 1.0 - 13-march-2019
 */
public class UserDto {

    private int userId;
    private String username;
    private String firstName;
    private String lastName;
    private String oldPassword;
    private String password;
    private String licenseNo;
    private String address;
    private boolean verifiedEmail;
    private Date createdDate;
    private int createdBy;
    private Date modifiedDate;
    private int modifiedBy;
    private String isDuplicate;
    private String description;
    private boolean status;
    private Role role;
    private String roleName;
    private int roleId;
    private UserDetails userDetails;
  
    public String getIsDuplicate() {
        return isDuplicate;
    }


    public void setIsDuplicate(String isDuplicate) {
        this.isDuplicate = isDuplicate;
    }


    public int getRoleId() {
        return roleId;
    }


    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }


    public Role getRole() {
        return role;
    }


    public void setRole(Role role) {
        this.role = role;
    }


    public int getUserId() {
        return userId;
    }


    public void setUserId(int userId) {
        this.userId = userId;
    }


    public String getUsername() {
        return username;
    }


    public void setUsername(String username) {
        this.username = username;
    }


    public String getFirstName() {
        return firstName;
    }


    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }


    public String getLastName() {
        return lastName;
    }


    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public String getPassword() {
        return password;
    }


    public void setPassword(String password) {
        this.password = password;
    }


    public String getLicenseNo() {
        return licenseNo;
    }


    public void setLicenseNo(String licenseNo) {
        this.licenseNo = licenseNo;
    }


    public String getAddress() {
        return address;
    }


    public void setAddress(String address) {
        this.address = address;
    }


    public boolean isVerifiedEmail() {
        return verifiedEmail;
    }


    public void setVerifiedEmail(boolean verifiedEmail) {
        this.verifiedEmail = verifiedEmail;
    }


    public Date getCreatedDate() {
        return createdDate;
    }


    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }


    public int getCreatedBy() {
        return createdBy;
    }


    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }


    public Date getModifiedDate() {
        return modifiedDate;
    }


    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }


    public int getModifiedBy() {
        return modifiedBy;
    }


    public void setModifiedBy(int modifiedBy) {
        this.modifiedBy = modifiedBy;
    }


    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }


    public boolean isStatus() {
        return status;
    }


    public void setStatus(boolean status) {
        this.status = status;
    }

    
    public UserDetails getUserDetails() {
		return userDetails;
	}


	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}


	@Override
    public String toString() {
        return "UserDto{" +
            "userId=" + userId + ", username='" + username + '\'' + 
               ", firstName='" + firstName + '\''+
                 ", password='" + password + '\''+
               ", lastName='" + lastName + '\''
            //+", licenceNo='" + licenseNo + '\'' 
             +", address='" + address + '\'' 
            +  ", description='" + description + '\''+
               ", status='" + status + '\''
            + createdDate + '\'' + createdBy + '\''  + modifiedBy + '\''
             + '}';
    }


	public String getOldPassword() {
		return oldPassword;
	}


	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}


	public String getRoleName() {
		return roleName;
	}


	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}


/*	public Role getRole() {
		return role;
	}


	public void setRole(Role role) {
		this.role = role;
	}*/
    
}
