/**
 * 
 */
package com.crelps.dto;

import java.util.List;

import com.crelps.model.PropertyAttachement;
import com.crelps.model.PropertyDetails;
import com.crelps.model.PropertyGallery;
import com.crelps.model.PropertyType;
import com.crelps.model.State;
import com.crelps.model.User;

/**
 * Class Information - This class is user for fetch the menu list from the data
 * base
 * 
 * @author KarunaS
 * @version 1.0 - 03-April-2019
 */
public class PropertyDto {

    private int propertyId;    
    private String propertyName;
    private String price;
    private boolean publishProperty;
    private String city ;
    private String state ;
    private String phone; 
    private PropertyDetails propertyDetails;
    private String addressOne;
    private String addressTwo;
    private String zipCode ;
    private String propertyStatus; 
    private String contactName ;
	private int subTypeId[];
	private User user;
	private PropertyType propertyType;
	private boolean status;
	private String createdDate;
	private int createdBy;
	private String modifiedDate;
	private int modifiedBy;
	private int totalCount;
	private int saleCount;
	private int leaseCount;
	private int activeCount;
	private int draftCount;
	private String defaultImage;
	private String contactEmail;
	private String defaultImagePath;
	private String thumbnailImagePath;
	private String leasePriceType;
	private String phoneTwo;
    private String contactEmailTwo;
    private String contactNameTwo;
	private String latitude;
	private String longitude;
	private String companyNameOne;
    private String companyNameTwo;
    private State stateData; 
	

  
    public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getThumbnailImagePath() {
		return thumbnailImagePath;
	}
	public void setThumbnailImagePath(String thumbnailImagePath) {
		this.thumbnailImagePath = thumbnailImagePath;
	}
	public String getDefaultImagePath() {
		return defaultImagePath;
	}
	public void setDefaultImagePath(String defaultImagePath) {
		this.defaultImagePath = defaultImagePath;
	}
	
	public int getSaleCount() {
		return saleCount;
	}

	public void setSaleCount(int saleCount) {
		this.saleCount = saleCount;
	}

	public int getLeaseCount() {
		return leaseCount;
	}

	public void setLeaseCount(int leaseCount) {
		this.leaseCount = leaseCount;
	}

	private List<PropertyGallery> propertyGallery;
	private List<PropertyAttachement> propertyAttachement;
	
	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public PropertyType getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(PropertyType propertyType) {
		this.propertyType = propertyType;
	}

	
	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public boolean isPublishProperty() {
		return publishProperty;
	}

	public void setPublishProperty(boolean publishProperty) {
		this.publishProperty = publishProperty;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}


    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

  
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public PropertyDetails getPropertyDetails() {
        return propertyDetails;
    }

    public void setPropertyDetails(PropertyDetails propertyDetails) {
        this.propertyDetails = propertyDetails;
    }

    public String getAddressOne() {
        return addressOne;
    }

    public void setAddressOne(String addressOne) {
        this.addressOne = addressOne;
    }

    public String getAddressTwo() {
        return addressTwo;
    }

    public void setAddressTwo(String addressTwo) {
        this.addressTwo = addressTwo;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getPropertyStatus() {
        return propertyStatus;
    }

    public void setPropertyStatus(String propertyStatus) {
        this.propertyStatus = propertyStatus;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public int[] getSubTypeId() {
        return subTypeId;
    }

    public void setSubTypeId(int[] subTypeId) {
        this.subTypeId = subTypeId;
    }

	public String getDefaultImage() {
		return defaultImage;
	}

	public void setDefaultImage(String defaultImage) {
		this.defaultImage = defaultImage;
	}

	public List<PropertyGallery> getPropertyGallery() {
		return propertyGallery;
	}

	public void setPropertyGallery(List<PropertyGallery> propertyGallery) {
		this.propertyGallery = propertyGallery;
	}

	public List<PropertyAttachement> getPropertyAttachement() {
		return propertyAttachement;
	}

	public void setPropertyAttachement(List<PropertyAttachement> propertyAttachement) {
		this.propertyAttachement = propertyAttachement;
	}

	public int getActiveCount() {
		return activeCount;
	}
	public void setActiveCount(int activeCount) {
		this.activeCount = activeCount;
	}
	public int getDraftCount() {
		return draftCount;
	}
	public void setDraftCount(int draftCount) {
		this.draftCount = draftCount;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
    public String getLeasePriceType() {
        return leasePriceType;
    }
    public void setLeasePriceType(String leasePriceType) {
        this.leasePriceType = leasePriceType;
    }
    public String getPhoneTwo() {
        return phoneTwo;
    }
    public void setPhoneTwo(String phoneTwo) {
        this.phoneTwo = phoneTwo;
    }
    public String getContactEmailTwo() {
        return contactEmailTwo;
    }
    public void setContactEmailTwo(String contactEmailTwo) {
        this.contactEmailTwo = contactEmailTwo;
    }
    public String getContactNameTwo() {
        return contactNameTwo;
    }
    public void setContactNameTwo(String contactNameTwo) {
        this.contactNameTwo = contactNameTwo;
    }
    public String getCompanyNameOne() {
        return companyNameOne;
    }
    public void setCompanyNameOne(String companyNameOne) {
        this.companyNameOne = companyNameOne;
    }
    public String getCompanyNameTwo() {
        return companyNameTwo;
    }
    public void setCompanyNameTwo(String companyNameTwo) {
        this.companyNameTwo = companyNameTwo;
    }
    public State getStateData() {
        return stateData;
    }
    public void setStateData(State stateData) {
        this.stateData = stateData;
    }

}
