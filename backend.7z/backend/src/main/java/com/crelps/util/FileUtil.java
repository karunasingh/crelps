package com.crelps.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.crelps.config.Translator;
import com.crelps.constant.Constant;

/**
 * Utility class to do file operations
 * 
 * @author varunb
 *
 */
public class FileUtil {
	private static final Logger log = LoggerFactory.getLogger(FileUtil.class);

	/**
	 * Method to create a directory
	 * 
	 * @author varunb
	 * @param id
	 * @param dirPath
	 * @return message
	 */
	public static String createDir(int id, String dirPath) {
		log.info("FileUtil :: createTransactionDir() Method start.");
		File attachmentsDirectory = new File(Constant.ATTACHMENTS_PATH + "/attachments/" + id + dirPath);
		if (!attachmentsDirectory.exists()) {
			boolean isTransDirCreated = attachmentsDirectory.mkdirs();
			if (isTransDirCreated) {
				attachmentsDirectory.setReadable(true, false);
				attachmentsDirectory.setWritable(true, false);
				attachmentsDirectory.setExecutable(true, false);
			}
		}
		log.info("FileUtil :: createTransactionDir() Method start.");
		return attachmentsDirectory.getPath();
	}

	/**
	 * Method to save a file
	 * 
	 * @author varunb
	 * @param multipartFile
	 * @param path
	 * @return message
	 */
	public static String doUpload(MultipartFile multipartFile, String path) {
		log.info("FileUtil :: doUpload() Method start.");
		File files = new File(path);
		try (OutputStream outputStream = new FileOutputStream(files);) {
			IOUtils.copy(multipartFile.getInputStream(), outputStream);
			log.info("FileUtil :: doUpload() Method end.");
			return Translator.toLocale("lang.success");
		} catch (Exception e) {
			log.error("Exception in FileUtil :: doUpload() ", e);
			return Translator.toLocale("lang.failure");
		}
	}

	/**
	 * method is used to delete the file from folder
	 * 
	 * @author varunb
	 * @param attachmentPath
	 * @return
	 */
	public static String deleteFile(String attachmentPath) {
		log.info("FileUtil :: deleteFile() Method start.");
		File file = new File(Constant.ATTACHMENTS_PATH + "/attachments/" + attachmentPath.split("attachments/")[1]);
		if (file.exists()) {
			file.delete();
		}
		log.info("FileUtil :: deleteFile() Method end.");
		return Translator.toLocale("lang.success");
	}
}
