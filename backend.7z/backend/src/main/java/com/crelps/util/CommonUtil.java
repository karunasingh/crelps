package com.crelps.util;

import java.util.Base64;

/**
 * @author karunas
 * 
 */
public class CommonUtil {

    private CommonUtil(){
        
    }
	/**
	 * method id used to encode the plaintext
	 * 
	 * @author karunas
	 * @param plainText
	 * @return string
	 */
	public static String encoder(String plainText) {
		return Base64.getEncoder().encodeToString(plainText.getBytes());
	}

	/**
	 * method id used to decode the encrypted
	 * 
	 * @author karunas
	 * @param encrypted
	 * @return string
	 */
	public static String decoder(String encrypted) {
		return new String(Base64.getDecoder().decode(encrypted));
	}
}
