package com.crelps.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crelps.constant.Constant;
import com.crelps.model.Property;

/**
 * Utility class to get coordinates from location
 * 
 * @author varunB
 */
public class LocationUtil {

	private static final Logger log = LoggerFactory.getLogger(LocationUtil.class);

	private String getPropertyCordinates(String url) throws Exception {
		log.info("LocationUtil :: getRequest() method start.");
		PostMethod post = new PostMethod(url);
		HttpClient httpclient = new HttpClient();
		httpclient.executeMethod(post);
		String xmlOutput = post.getResponseBodyAsString();
		log.info("LocationUtil :: getRequest() method start.");
		return xmlOutput;
	}

	/**
	 * Method to get coordinates from location
	 * 
	 * @param address
	 * @return Map<"lat/lon", coordinate>
	 * @author varunb
	 */
	public Map<String, String> getCoordinates(Property property) {
		log.info("LocationUtil :: getCoordinates() method start.");

		StringBuffer query = new StringBuffer();
		String queryResult = null;

		Map<String, String> coordinateDetails = new HashMap<String, String>();
		query.append(Constant.GOOGLE_API_URL);

		if (property.getAddressOne() != null && !property.getAddressOne().isEmpty()) {
			query.append(property.getAddressOne());
		}
		if (property.getAddressTwo() != null && !property.getAddressTwo().isEmpty()) {
			query.append(property.getAddressTwo());
		}
		if (property.getCity() != null && !property.getCity().isEmpty()) {
			query.append(property.getCity());
		}
		if (property.getState() != null && !property.getState().isEmpty()) {
			query.append(property.getState());
		}
		if (property.getZipCode() != null && !property.getZipCode().isEmpty()) {
			query.append(property.getZipCode());
		}

		query.append("&key=" + Constant.GOOGLE_API_KEY);

		log.info("Query:", query);

		try {
			queryResult = getPropertyCordinates(query.toString().replaceAll(" ", "+"));

			JSONArray result = ((JSONArray) ((JSONObject) JSONValue.parse(queryResult)).get("results"));

			if (result != null && result.size() > 0 && !result.isEmpty()) {
				JSONObject location = ((JSONObject) ((JSONObject) ((JSONObject) result.get(0)).get("geometry"))
						.get("location"));
				coordinateDetails.put("lon", String.valueOf(location.get("lng")));
				coordinateDetails.put("lat", String.valueOf(location.get("lat")));
			}
		} catch (Exception e) {
			log.error("Error when trying to get data with the following query " , query);
		}
		log.info("LocationUtil :: getCoordinates() method end.");
		return coordinateDetails;
	}

}
