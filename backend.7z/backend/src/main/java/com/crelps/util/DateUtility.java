/**
 * 
 */
package com.crelps.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.crelps.constant.Constant;

/**
 * @author karunas
 * @date 25 march-2019
 *
 */
public class DateUtility {

	/**
	 * @description This method is used to get the current Time in String format
	 *              HHMMSS.
	 * @author KarunaS
	 * @date 25 march-2019
	 * @return String
	 * @return time String
	 */
	public static String getCurrentDateTime() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(Constant.DB_DATE_TIME_FORMAT);
		 return sdf.format(date);
	}

}
