package com.crelps.util;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 * Utility class to save Image
 * 
 * @author varunB
 *
 */
public class ImageUtil {
	private static final Logger log = LoggerFactory.getLogger(ImageUtil.class);

	/**
	 * Method to to save Image
	 * 
	 * @param file
	 * @param fileName
	 * @param path
	 * @param type
	 * @author varunB
	 */
	public static void imageIoWrite(MultipartFile file, String fileName, String path) {
		log.info("ImageUtil :: imageIoWrite() method started.");
		
		try (InputStream in = file.getInputStream()){
			Image image = ImageIO.read(in);
			ImageIcon icon = new ImageIcon(image);
			int height;
			int width;
			
			if (fileName.startsWith("thumbnail_")) {
				width = 140;
				height = 93;
			} else if(fileName.startsWith("thumbnailCompanyLogo_")){
			    width = 200;
                height = 70; 
			} 
			else {
				height = icon.getIconHeight();
				width = icon.getIconWidth();
			}
			BufferedImage bi = createResizedCopy(image, width, height, true);
			ImageIO.write(bi, "jpg", new File(ResourceUtils.getFile(path), fileName));
			log.info("ImageUtil :: imageIoWrite() method end.");
		} catch (Exception e) {
			log.error("ImageUtil :: imageIoWrite() method failed.", e);
		}
		log.info("ImageUtil :: imageIoWrite() method executed.");
	}

	private static BufferedImage createResizedCopy(Image originalImage, int scaledWidth, int scaledHeight,
			boolean preserveAlpha) {
		int imageType = preserveAlpha ? BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB;
		BufferedImage scaledBI = new BufferedImage(scaledWidth, scaledHeight, imageType);
		Graphics2D g = scaledBI.createGraphics();
		if (preserveAlpha) {
			g.setComposite(AlphaComposite.Src);
		}
		g.drawImage(originalImage, 0, 0, scaledWidth, scaledHeight, null);
		g.dispose();
		return scaledBI;
	}

}
