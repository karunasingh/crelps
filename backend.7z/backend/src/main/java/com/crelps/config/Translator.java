package com.crelps.config;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

/**
 * Class Information - This class is use for translate the message language
 * 
 * @author NiteshD
 * @version 1.0 - 24-May-2019
 */
@Component
public class Translator {

    private static ResourceBundleMessageSource messageSource;

    /**
     * This method is use for translate the message language
     * @author NiteshD
     * @param ResourceBundleMessageSource messageSource
     */
    @Autowired
    Translator(ResourceBundleMessageSource messageSource) {
        Translator.messageSource = messageSource;
    }

    /**
     * Method to get the string message from message.properties class
     * 
     * @author NiteshD
     * @param String msgCode
     * @return string type message
     */
    public static String toLocale(String msgCode) {
        Locale locale = LocaleContextHolder.getLocale();
        return messageSource.getMessage(msgCode, null, locale);
    }
}
