/**
 * 
 */
package com.crelps.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Class Information - This class is used for save the user details
 * @author KarunaS
 * @version 1.0 - 03-April-2019
 */

@Entity
@Table(name="property_details")
public class PropertyDetails {

    @Id
    @Column(name = "property_detail_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int propertyDetailId; 
    private String buildingSize;
    private String lotSize;
    private String yearBuilt;
    private String noOfStories;
    private String saleType;
    private String zoning;
    private String spaceAvailable;
    private String tenancy;
    private String noi;
    private String capRate;
    private String area;
    private String description;
    
    @JsonIgnore
    @OneToOne
    @JoinColumn(name="property_id")
    private Property property; 
    
    public int getPropertyDetailId() {
        return propertyDetailId;
    }

    public void setPropertyDetailId(int propertyDetailId) {
        this.propertyDetailId = propertyDetailId;
    }

    public String getBuildingSize() {
        return buildingSize;
    }

    public void setBuildingSize(String buildingSize) {
        this.buildingSize = buildingSize;
    }

    public String getLotSize() {
        return lotSize;
    }

    public void setLotSize(String lotSize) {
        this.lotSize = lotSize;
    }

    public String getYearBuilt() {
        return yearBuilt;
    }

    public void setYearBuilt(String yearBuilt) {
        this.yearBuilt = yearBuilt;
    }

    public String getNoOfStories() {
        return noOfStories;
    }

    public void setNoOfStories(String noOfStories) {
        this.noOfStories = noOfStories;
    }

    public String getSaleType() {
        return saleType;
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType;
    }

    public String getZoning() {
        return zoning;
    }

    public void setZoning(String zoning) {
        this.zoning = zoning;
    }

    public String getSpaceAvailable() {
        return spaceAvailable;
    }

    public void setSpaceAvailable(String spaceAvailable) {
        this.spaceAvailable = spaceAvailable;
    }

    public String getTenancy() {
        return tenancy;
    }

    public void setTenancy(String tenancy) {
        this.tenancy = tenancy;
    }

    public String getNoi() {
        return noi;
    }

    public void setNoi(String noi) {
        this.noi = noi;
    }

    public String getCapRate() {
        return capRate;
    }

    public void setCapRate(String capRate) {
        this.capRate = capRate;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Property getProperty() {
        return property;
    }

    public void setProperty(Property property) {
        this.property = property;
    }



}
