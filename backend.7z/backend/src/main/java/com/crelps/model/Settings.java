/**
 * 
 */
package com.crelps.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Class Information - This class is used for save the setting 
 * @author KarunaS
 * @version 1.0 - 10-May-2019
 */
@Entity
@Table(name="settings")
public class Settings {
    
    @Id
    @Column(name = "settings_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int settingsId; 
    private String pricePerProperty;
    private boolean promotional ;
    
    
    public int getSettingsId() {
        return settingsId;
    }
    public void setSettingsId(int settingsId) {
        this.settingsId = settingsId;
    }
    public String getPricePerProperty() {
        return pricePerProperty;
    }
    public void setPricePerProperty(String pricePerProperty) {
        this.pricePerProperty = pricePerProperty;
    }
    public boolean isPromotional() {
        return promotional;
    }
    public void setPromotional(boolean promotional) {
        this.promotional = promotional;
    }
    
    
    
}
