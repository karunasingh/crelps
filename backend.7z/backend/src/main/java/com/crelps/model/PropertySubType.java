package com.crelps.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.crelps.dto.PropertySubTypeDto;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Class Information - This class is used for save the property sub type 
 * @author KarunaS
 * @version 1.0 - 03-April-2019
 */
@Entity
@Table(name="property_sub_types")
public class PropertySubType {
    
	@Id
	@Column(name = "sub_type_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int subTypeId;
	
	@Column(name="sub_type_name")
    private String subTypeName;
	
	private boolean status;
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "type_id")
	private PropertyType propertyType;
	
	  public PropertySubTypeDto toPropertySubTypeDto() {
          PropertySubTypeDto propertySubTypeDto = new PropertySubTypeDto();
          propertySubTypeDto.setSubTypeId(this.subTypeId);
          propertySubTypeDto.setSubTypeName(this.subTypeName);
          propertySubTypeDto.setStatus(this.status);
          return propertySubTypeDto;
       }
	
	public int getSubTypeId() {
		return subTypeId;
	}

	public void setSubTypeId(int subTypeId) {
		this.subTypeId = subTypeId;
	}

	public String getSubTypeName() {
		return subTypeName;
	}

	public void setSubTypeName(String subTypeName) {
		this.subTypeName = subTypeName;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public PropertyType getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(PropertyType propertyType) {
		this.propertyType = propertyType;
	}
	 
}
