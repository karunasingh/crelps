/**
 * 
 */
package com.crelps.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.crelps.dto.StateDto;

/**
 * Class Information - entity class of state
 * 
 * @author KarunaS
 * @version 1.0 - 15-June-2019
 */

@Entity
@Table(name = "state")
public class State {
    @Id
    @Column(name = "state_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int stateId;

    private String stateName;

    private String stateCode;

    private boolean status;
    
    public StateDto toStateDto() {
        StateDto stateDto = new StateDto();
        stateDto.setStateId(this.stateId);
        stateDto.setStateName(this.stateName);
        stateDto.setStatus(this.status);
        stateDto.setStateCode(this.stateCode);
        return stateDto;
    }

    public int getStateId() {
        return stateId;
    }

    public void setStateId(int stateId) {
        this.stateId = stateId;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }
 
    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

}
