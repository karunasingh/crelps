package com.crelps.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.Transient;

import com.crelps.dto.PropertyDto;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * This class is use for the model fields for the data base
 * @author karunaS
 * @date 25 march-2019
 *
 */

@Entity
@Table(name="properties")
public class Property implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
	@Column(name = "property_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int propertyId;	
	private String propertyName;
	private String price;
	private String addressOne;
	private String addressTwo;
	private String city ;
	private String state ;
	private String zipCode ;
	private boolean publishProperty ;
	private String propertyStatus; 
	private String contactName ;
    private String phone;  
    private boolean status;
    private String thumbnailImagePath;
    private String subTypeId;
    private String leasePriceType;
    private String phoneTwo;
    private String contactEmailTwo;
    private String contactNameTwo;
    private String companyNameOne;
    private String companyNameTwo;
    
	@Transient
    private transient long totalCount;
    
    @Transient
	private transient long saleCount;
    
    @Transient
	private transient long leaseCount;
    
    @Transient
	private transient long activeCount;
    
    @Transient
	private transient long draftCount;

    @Transient
    private transient String defaultImage;
    
    
    @Transient
	private transient int userId;
    @Transient
	private transient int propertyTypeId;
    @Transient
	private transient String propertySubTypeId;
    
    @Transient
    private transient int stateId ;

    @JsonIgnore
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_id")
	private User user;

    @OneToOne
	@JoinColumn(name="type_id")
	private PropertyType propertyType; 
    
	@JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "property")
    private List<PropertyGallery> propertyGallery;
	
	@JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "property")
    private List<PropertyAttachement> propertyAttachement;

    @OneToOne(mappedBy = "property", cascade = {CascadeType.ALL})
    private PropertyDetails propertyDetails;
    
    @OneToOne
    @JoinColumn(name="state_id")
    private State stateData; 
    
	 		
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	private int createdBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;

	private int modifiedBy;
	
	private String latitude;
	
	private String longitude;
	
	private String contactEmail;

	private String defaultImagePath;
	
    public PropertyDto toPropertyDto() {
        PropertyDto propertyDto = new PropertyDto();
        propertyDto.setPropertyId(this.propertyId);
        propertyDto.setPropertyName(this.propertyName);
        propertyDto.setPrice(this.price);
        propertyDto.setPropertyStatus(this.propertyStatus);
        propertyDto.setPublishProperty(this.publishProperty);
        propertyDto.setCreatedBy(this.createdBy);
        propertyDto.setModifiedBy(this.modifiedBy);
        propertyDto.setPropertyStatus(this.propertyStatus);
        propertyDto.setStatus(this.status);
   
        for(PropertyGallery propertyGallery1 : this.propertyGallery)
        {
            if(propertyGallery1.isDefaultImage()){
                propertyDto.setDefaultImage(propertyGallery1.getImagePath());       
            }
        }
        propertyDto.setAddressOne(this.addressOne);
        propertyDto.setAddressTwo(this.addressTwo);
        propertyDto.setCity(this.city);
        propertyDto.setState(this.state);
        propertyDto.setZipCode(this.zipCode);
        propertyDto.setPropertyDetails(this.propertyDetails);
        propertyDto.setCompanyNameOne(this.companyNameOne);
        propertyDto.setCompanyNameTwo(this.companyNameTwo);
        propertyDto.setContactEmail(this.contactEmail);
        propertyDto.setPhone(this.phone);
        propertyDto.setPhoneTwo(this.phoneTwo);
        propertyDto.setContactEmailTwo(this.contactEmailTwo);
        return propertyDto;
    }
	

    public String getDefaultImagePath() {
		return defaultImagePath;
	}
	public void setDefaultImagePath(String defaultImagePath) {
		this.defaultImagePath = defaultImagePath;
	}
	public int getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public String getSubTypeId() {
        return subTypeId;
    }

    public void setSubTypeId(String subTypeId) {
        this.subTypeId = subTypeId;
    }


    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }


    public String getPrice() {
        return price;
    }



    public void setPrice(String price) {
        this.price = price;
    }
    public boolean isPublishProperty() {
		return publishProperty;
	}



	public void setPublishProperty(boolean publishProperty) {
		this.publishProperty = publishProperty;
	}



	public String getState() {
        return state;
    }



    public void setState(String state) {
        this.state = state;
    }





    public String getContactName() {
        return contactName;
    }



    public void setContactName(String contactName) {
        this.contactName = contactName;
    }


    public String getPhone() {
        return phone;
    }



    public void setPhone(String phone) {
        this.phone = phone;
    }



    public boolean isStatus() {
        return status;
    }



    public void setStatus(boolean status) {
        this.status = status;
    }



    public int getUserId() {
        return userId;
    }



    public void setUserId(int userId) {
        this.userId = userId;
    }



    public int getPropertyTypeId() {
        return propertyTypeId;
    }



    public void setPropertyTypeId(int propertyTypeId) {
        this.propertyTypeId = propertyTypeId;
    }


    public String getDefaultImage(){
    	return defaultImage;
    }
    
    public void setDefaultImage(String defaultImage){
    	this.defaultImage = defaultImage;
    }

    public User getUser() {
        return user;
    }



    public String getPropertySubTypeId() {
        return propertySubTypeId;
    }



    public void setPropertySubTypeId(String propertySubTypeId) {
        this.propertySubTypeId = propertySubTypeId;
    }



    public void setUser(User user) {
        this.user = user;
    }



    public PropertyType getPropertyType() {
        return propertyType;
    }



    public void setPropertyType(PropertyType propertyType) {
        this.propertyType = propertyType;
    }



    public List<PropertyGallery> getPropertyGallery() {
        return propertyGallery;
    }



    public void setPropertyGallery(List<PropertyGallery> propertyGallery) {
        this.propertyGallery = propertyGallery;
    }




    public Date getCreatedDate() {
        return createdDate;
    }



    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }



    public int getCreatedBy() {
        return createdBy;
    }



    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }



    public Date getModifiedDate() {
        return modifiedDate;
    }



    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }



    public int getModifiedBy() {
        return modifiedBy;
    }



    public void setModifiedBy(int modifiedBy) {
        this.modifiedBy = modifiedBy;
    }



  

    public String getAddressOne() {
        return addressOne;
    }



    public void setAddressOne(String addressOne) {
        this.addressOne = addressOne;
    }



    public String getAddressTwo() {
        return addressTwo;
    }



    public void setAddressTwo(String addressTwo) {
        this.addressTwo = addressTwo;
    }



    public String getCity() {
        return city;
    }



    public void setCity(String city) {
        this.city = city;
    }



    public String getZipCode() {
        return zipCode;
    }



    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }



    public String getPropertyStatus() {
        return propertyStatus;
    }



    public void setPropertyStatus(String propertyStatus) {
        this.propertyStatus = propertyStatus;
    }

    public List<PropertyAttachement> getPropertyAttachement() {
        return propertyAttachement;
    }



    public void setPropertyAttachement(List<PropertyAttachement> propertyAttachement) {
        this.propertyAttachement = propertyAttachement;
    }



    public PropertyDetails getPropertyDetails() {
        return propertyDetails;
    }



    public void setPropertyDetails(PropertyDetails propertyDetails) {
        this.propertyDetails = propertyDetails;
    }
    
    
    public long getTotalCount() {
		return totalCount;
	}



	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}



	public long getSaleCount() {
		return saleCount;
	}



	public void setSaleCount(long saleCount) {
		this.saleCount = saleCount;
	}



	public long getLeaseCount() {
		return leaseCount;
	}



	public void setLeaseCount(long leaseCount) {
		this.leaseCount = leaseCount;
	}



	public long getActiveCount() {
		return activeCount;
	}



	public void setActiveCount(long activeCount) {
		this.activeCount = activeCount;
	}



	public long getDraftCount() {
		return draftCount;
	}



	public void setDraftCount(long draftCount) {
		this.draftCount = draftCount;
	}

	public String getLatitude() {
		return latitude;
	}



	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}



	public String getLongitude() {
		return longitude;
	}



	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}



	public String getContactEmail() {
		return contactEmail;
	}



	public String getLeasePriceType() {
        return leasePriceType;
    }
    public void setLeasePriceType(String leasePriceType) {
        this.leasePriceType = leasePriceType;
    }
    public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	public String getThumbnailImagePath() {
		return thumbnailImagePath;
	}
	public void setThumbnailImagePath(String thumbnailImagePath) {
		this.thumbnailImagePath = thumbnailImagePath;
	}
    public String getPhoneTwo() {
        return phoneTwo;
    }
    public void setPhoneTwo(String phoneTwo) {
        this.phoneTwo = phoneTwo;
    }
    public String getContactEmailTwo() {
        return contactEmailTwo;
    }
    public void setContactEmailTwo(String contactEmailTwo) {
        this.contactEmailTwo = contactEmailTwo;
    }
    public String getContactNameTwo() {
        return contactNameTwo;
    }
    public void setContactNameTwo(String contactNameTwo) {
        this.contactNameTwo = contactNameTwo;
    }
    public String getCompanyNameOne() {
        return companyNameOne;
    }
    public void setCompanyNameOne(String companyNameOne) {
        this.companyNameOne = companyNameOne;
    }
    public String getCompanyNameTwo() {
        return companyNameTwo;
    }
    public void setCompanyNameTwo(String companyNameTwo) {
        this.companyNameTwo = companyNameTwo;
    }

    public State getStateData() {
        return stateData;
    }
    public void setStateData(State stateData) {
        this.stateData = stateData;
    }


    public int getStateId() {
        return stateId;
    }


    public void setStateId(int stateId) {
        this.stateId = stateId;
    }

    
}


