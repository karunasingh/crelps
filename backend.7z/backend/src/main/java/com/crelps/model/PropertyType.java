/**
 * 
 */
package com.crelps.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.crelps.dto.PropertyTypeDto;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Class Information - This class is used for save the property type 
 * @author KarunaS
 * @version 1.0 - 03-April-2019
 */
@Entity
@Table(name="property_types")
public class PropertyType {
    
	@Id
	@Column(name = "type_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int typeId;
	
	private String typeName;
    
    private boolean status;
    
    private String propertyStatus;
    
    //@JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy="propertyType")
    private List<PropertySubType> propertySubTypeList;
    
    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy="propertyType")
    private List<Property> propertyList;
    
    public PropertyTypeDto toPropertyTypeDto() {
        PropertyTypeDto propertyTypeDto = new PropertyTypeDto();
        propertyTypeDto.setTypeId(this.typeId);
        propertyTypeDto.setTypeName(this.typeName);
        propertyTypeDto.setStatus(this.status);
        propertyTypeDto.setPropertyStatus(this.propertyStatus);
        return propertyTypeDto;
    }
    
    public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public List<PropertySubType> getPropertySubTypeList() {
		return propertySubTypeList;
	}

	public void setPropertySubTypeList(List<PropertySubType> propertySubTypeList) {
		this.propertySubTypeList = propertySubTypeList;
	}

	public List<Property> getPropertyList() {
		return propertyList;
	}

	public void setPropertyList(List<Property> propertyList) {
		this.propertyList = propertyList;
	}
	
	
	public String getPropertyStatus() {
        return propertyStatus;
    }

    public void setPropertyStatus(String propertyStatus) {
        this.propertyStatus = propertyStatus;
    }
  
}
