/**
 * 
 */
package com.crelps.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.annotation.Transient;

/**
 * Class Information - entity class of billing
 * 
 * @author KarunaS
 * @version 1.0 - 24-May-2019
 */

@Entity
@Table(name = "user_billing")
public class Billing {    
    @Id
    @Column(name = "billing_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int billingId;

    private String cardNo;

    private String cardName;

    private String cvvNo;

    private String cardHolderName;

    private String addressOne;
    
    private String addressTwo;
    
    private String city;
    
    private String state;
    
    private String country;
    
    private String zipCode;
    
    private String phone;
    
    private String validThruDate;
    
    @Transient
    private transient long month;
    
    @Transient
    private transient long year;

   // @OneToOne(mappedBy = "billing")
    @OneToOne
    @JoinColumn(name="user_id")
    private User user;
    
//    @Temporal(TemporalType.DATE)
//    @Column(name = "valid_thru_date")
//    private Date validThruDate;

    public int getBillingId() {
        return billingId;
    }

    public void setBillingId(int billingId) {
        this.billingId = billingId;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardName() {
        return cardName;
    }

    public void setCardName(String cardName) {
        this.cardName = cardName;
    }

    public String getCvvNo() {
        return cvvNo;
    }

    public void setCvvNo(String cvvNo) {
        this.cvvNo = cvvNo;
    }

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    public String getAddressOne() {
        return addressOne;
    }

    public void setAddressOne(String addressOne) {
        this.addressOne = addressOne;
    }

    public String getAddressTwo() {
        return addressTwo;
    }

    public void setAddressTwo(String addressTwo) {
        this.addressTwo = addressTwo;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getValidThruDate() {
        return validThruDate;
    }

    public void setValidThruDate(String validThruDate) {
        this.validThruDate = validThruDate;
    }

    public long getMonth() {
        return month;
    }

    public void setMonth(long month) {
        this.month = month;
    }

    public long getYear() {
        return year;
    }

    public void setYear(long year) {
        this.year = year;
    }
    
    
}
