/**
 * ===========================================================================
 * File Name Role.java
 *
 * Created on 05-March-2019
 *
 * This code contains copyright information which is the proprietary property
 * of crelps. No part of this code may be reproduced, stored or transmitted
 * in any form without the prior written permission of crelps.
 *
 * Copyright (C) crelps. 2019
 * All rights reserved.
 *
 * Modification history:
 * $Log: Role.java,v $
 * ===========================================================================
 */
package com.crelps.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Class Information - This class is create the data base schema for role table
 *
 * @author KarunaS
 * @version 1.0 - 13-March-2018
 */
@Entity
@Table(name = "roles")
public class Role {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int roleId;
	
	private String role;
	
	private String description;
	
	private boolean status;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "role", cascade=CascadeType.ALL)
	private List<Menu> menuList;
	
	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<Menu> getMenuList() {
		return menuList;
	}

	public void setMenuList(List<Menu> menuList) {
		this.menuList = menuList;
	}
}
