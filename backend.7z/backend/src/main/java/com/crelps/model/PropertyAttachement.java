/**
 * 
 */
package com.crelps.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Class Information - This class is used for save the property attachment
 * @author KarunaS
 * @version 1.0 - 20-April-2019
 */
@Entity
@Table(name="property_attachement")
public class PropertyAttachement {
    @Id
    @Column(name = "attachement_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int attachementId; 
    private String originelAttachementName;
    private String attachementPath;
    @Column(columnDefinition = "text")
    private String attachementDescription;
    private boolean status;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="property_id")
    private Property property;
    
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    private int createdBy;
    
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;

    private int modifiedBy;

    public int getAttachementId() {
        return attachementId;
    }

    public void setAttachementId(int attachementId) {
        this.attachementId = attachementId;
    }

    public String getOriginelAttachementName() {
        return originelAttachementName;
    }

    public void setOriginelAttachementName(String originelAttachementName) {
        this.originelAttachementName = originelAttachementName;
    }

    public String getAttachementPath() {
        return attachementPath;
    }

    public void setAttachementPath(String attachementPath) {
        this.attachementPath = attachementPath;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Property getProperty() {
        return property;
    }

    public void setProperty(Property property) {
        this.property = property;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public int getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public int getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(int modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

	public String getAttachementDescription() {
		return attachementDescription;
	}

	public void setAttachementDescription(String attachementDescription) {
		this.attachementDescription = attachementDescription;
	}


}
