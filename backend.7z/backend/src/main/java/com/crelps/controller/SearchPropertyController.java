/**
 * 
 */
package com.crelps.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crelps.constant.Constant;
import com.crelps.dto.ApiResponse;
import com.crelps.dto.SearchPropertyDto;
import com.crelps.service.PropertyService;
import com.crelps.service.SearchPropertyService;
import com.crelps.service.UserService;

/**
 * Class Information - This class is use for the advanced search property
 * 
 * @author KarunaS
 * @version 1.0 - 24-April-2019
 */
@RestController
@RequestMapping("/search")
public class SearchPropertyController {

    private static final Logger log = LoggerFactory.getLogger(PropertyService.class);

    @Autowired
    private SearchPropertyService searchPropertyService;

    @Autowired
    private PropertyService propertyService;

    @Autowired
    private UserService userService;

    /**
	 * This Method is used to get properties list
	 * 
	 * @author VarunB
	 * @param propertyTypeId
	 *            - search data based on property id
	 * @param propertyStatus
	 *            - search data based on property status
	 * @param searchFieldVal
	 *            - search data based on searchFieldVal
	 * @param city - search data based on city
	 * @param state - search data based on state
	 * @param zipcode- search data based on zipcode
	 * @param spaceUse- search data based on spaceUse
	 * @param tenancy- search data based on tenancy
	 * @param minCapRate- search data based on minCapRate
	 * @param maxCapRate- search data based on maxCapRate
	 * @param minLotSize- search data based on minLotSize
	 * @param maxLotSize- search data based on maxLotSize
	 * @param minSalePrice- search data based on minSalePrice
	 * @param maxSalePrice- search data based on maxSalePrice
	 * @param minLeasePrice- search data based on minLeasePrice
	 * @param maxLeasePrice- search data based on maxLeasePrice
	 * @param minYearBuilt- search data based on minYearBuilt
	 * @param maxYearBuilt- search data based on maxYearBuilt
	 * @param subTypeId- search data based on subTypeId
	 * @return ApiResponse return the success message , HTTP status code
	 */
    @GetMapping(value = "/searchProperties")
	public ApiResponse searchProperty(@RequestParam(value = "propertyStatus", required = true) String propertyStatus,
			@RequestParam(value = "searchFieldVal", required = false) String searchFieldVal,
			@RequestParam(value = "city", required = false) String city, 
			@RequestParam(value = "state", required = false) int state,
			@RequestParam(value = "zipcode", required = false) String zipcode,
			@RequestParam(value = "spaceUse", required = false) String spaceUse, 
			@RequestParam(value = "tenancy", required = false) String tenancy,
			@RequestParam(value = "minCapRate", required = false) String minCapRate, 
			@RequestParam(value = "maxCapRate", required = false) String maxCapRate, 
			@RequestParam(value = "minLotSize", required = false) String minLotSize,
			@RequestParam(value = "maxLotSize", required = false) String maxLotSize, 
			@RequestParam(value = "minSalePrice", required = false) String minSalePrice, 
			@RequestParam(value = "maxSalePrice", required = false) String maxSalePrice,
			@RequestParam(value = "minLeasePrice", required = false) String minLeasePrice, 
			@RequestParam(value = "maxLeasePrice", required = false) String maxLeasePrice,
			@RequestParam(value = "minYearBuilt", required = false) String minYearBuilt, 
			@RequestParam(value = "maxYearBuilt", required = false) String maxYearBuilt,
			@RequestParam(value = "minAvailableSpace", required = false) String minAvailableSpace, 
			@RequestParam(value = "maxAvailableSpace", required = false) String maxAvailableSpace,
			@RequestParam(value = "minBuildingSize", required = false) String minBuildingSize, 
			@RequestParam(value = "maxBuildingSize", required = false) String maxBuildingSize,
			@RequestParam(value = "subTypeId", required = false) String subTypeId) {
        log.info("SearchPropertyController :: searchProperty() executed.");
       SearchPropertyDto search = new SearchPropertyDto();
		search.propertyStatus = propertyStatus;
		search.searchFieldVal = searchFieldVal;
		search.city = city;
		search.state = state;
		search.zipcode = zipcode;
		search.spaceUse = spaceUse;
		if(!minSalePrice.equals("")){
		minSalePrice = minSalePrice.replaceAll(",", "").replace("$", "");
		minSalePrice = minSalePrice.substring(0,minSalePrice.indexOf('.'));
		}
		if(!maxSalePrice.equals("")){
		maxSalePrice = maxSalePrice.replaceAll(",", "").replace("$", "");
		maxSalePrice = maxSalePrice.substring(0,maxSalePrice.indexOf('.'));
		}
		minCapRate = minCapRate.replaceAll(",", "");
		maxCapRate = maxCapRate.replaceAll(",", "");
		minLotSize = minLotSize.replaceAll(",", "");
		maxLotSize = maxLotSize.replaceAll(",", "");
		minSalePrice = minSalePrice.replaceAll(",", "");
		maxSalePrice = maxSalePrice.replaceAll(",", "");
		minLeasePrice = minLeasePrice.replaceAll(",", "");
		maxLeasePrice = maxLeasePrice.replaceAll(",", "");
		minYearBuilt = minYearBuilt.replaceAll(",", "");
		maxYearBuilt = maxYearBuilt.replaceAll(",", "");
		minAvailableSpace = minAvailableSpace.replaceAll(",", "");
		maxAvailableSpace = maxAvailableSpace.replaceAll(",", "");
		minBuildingSize = minBuildingSize.replaceAll(",", "");
		maxBuildingSize = maxBuildingSize.replaceAll(",", "");
		search.tenancy = tenancy;
		search.minCapRate = minCapRate != "" ? Integer.parseInt(minCapRate) : 0;
		search.maxCapRate = maxCapRate != "" ? Integer.parseInt(maxCapRate) : 0;
		search.minLotSize = minLotSize != "" ? Integer.parseInt(minLotSize):0;
		search.maxLotSize =  maxLotSize!= "" ? Integer.parseInt(maxLotSize):0;
		search.minSalePrice = minSalePrice != "" ? Integer.parseInt(minSalePrice):0;
		search.maxSalePrice = maxSalePrice != "" ? Integer.parseInt(maxSalePrice):0;
		search.minLeasePrice = minLeasePrice != "" ? Integer.parseInt(minLeasePrice):0;
		search.maxLeasePrice =  maxLeasePrice!= "" ? Integer.parseInt(maxLeasePrice):0;
		search.minYearBuilt = minYearBuilt != "" ? Integer.parseInt(minYearBuilt):0;
		search.maxYearBuilt = maxYearBuilt != "" ? Integer.parseInt(maxYearBuilt):0;
		search.minBuildingSize = minBuildingSize != "" ? Integer.parseInt(minBuildingSize):0;
		search.maxBuildingSize =  maxBuildingSize!= "" ? Integer.parseInt(maxBuildingSize):0;
		search.minAvailableSpace =  minAvailableSpace!= "" ? Integer.parseInt(minAvailableSpace):0;
		search.maxAvailableSpace =  maxAvailableSpace!= "" ? Integer.parseInt(maxAvailableSpace):0;
		search.subTypeId = subTypeId;
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, searchPropertyService.serachProperty(search));
    }

    /**
     * This method is used to get properties details by property id
     * 
     * @author karunaS
     * @param propertyTypeId - data based on property id
     * @return ApiResponse return the success message , HTTP status code 
     */
    @GetMapping(value = "/getProperty/{propertyId}")
    public ApiResponse getPropertyById(@PathVariable int propertyId) {
        log.info("SearchPropertyController :: getPropertyById() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.findOne(propertyId));
    }

    /**
     * This method is used to user details by user name
     * 
     * @author karunaS
     * @param username - data based on user name
     * @return ApiResponse return the success message , HTTP status code 
     */
    @GetMapping(value = "/user/{username}")
    public ApiResponse getUserByEmail(@PathVariable String username) {
        log.info("UserController :: getUserByEmail() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, userService.findOne(username));
    }
}
