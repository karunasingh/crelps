/**
 * 
 */
package com.crelps.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crelps.constant.Constant;
import com.crelps.dto.ApiResponse;
import com.crelps.model.Billing;
import com.crelps.service.BillingService;
import com.crelps.service.PropertyService;

/**
 * Class Information - This class is use for the controller the billing details
 * 
 * @author KarunaS
 * @version 1.0 - 24-May-2019
 */
@RestController
@RequestMapping("/billing")
public class BillingController {
   private static final Logger log = LoggerFactory.getLogger(PropertyService.class);
    
   @Autowired
   private BillingService billingService;
   
   /**
    * This method is use for save the billing details in to the data base
    * 
    * @author KarunaS
    * @param Billing billing 
    * @return ApiResponse return the success message , HTTP status code and billing details
    */
   @PostMapping
   public ApiResponse create(@RequestBody Billing billing) {
       log.info("BillingController :: create() executed.");
       return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, billingService.save(billing));
   }
    
}
