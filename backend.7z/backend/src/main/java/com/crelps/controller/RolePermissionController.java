package com.crelps.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crelps.constant.Constant;
import com.crelps.dto.ApiResponse;
import com.crelps.service.RolePermissionService;

/**
 * Class Information - This class is Controller the role permission for menus
 * @author KarunaS
 * @version 1.0 - 27-March-2019
 */
@RestController
@RequestMapping("/roles")
public class RolePermissionController {
    private static final Logger log = LoggerFactory.getLogger(RolePermissionController.class);
    
    @Autowired
    private RolePermissionService rolePermissionService;
    
    /**
     * @author KarunaS
     * @date March 27, 2019
     * @return ApiResponse
     * @param roleId
     * @description get the Menus and SubMenus List base on role id
     */
   @GetMapping(value = "/getMenu")
    public ApiResponse getMenuList(@RequestParam int roleId) {
        log.info("RolePermissionControllor :: getMenuList() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, rolePermissionService.getMenuList(roleId));
    }
   
}
