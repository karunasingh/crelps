/**
 * ===========================================================================
 * File Name UserController.java
 *
 * Created on 05-March-2019
 *
 * This code contains copyright information which is the proprietary property
 * of crelps. No part of this code may be reproduced, stored or transmitted
 * in any form without the prior written permission of crelps.
 *
 * Copyright (C) crelps. 2019
 * All rights reserved.
 *
 * Modification history:
 * $Log: UserController.java,v $
 * ===========================================================================
 */
package com.crelps.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.crelps.constant.Constant;
import com.crelps.dto.ApiResponse;
import com.crelps.dto.UserDto;
import com.crelps.model.User;
import com.crelps.service.EmailService;
import com.crelps.service.UserService;

/**
 * Class Information - This class is used for maintaining the controller
 *
 * @author VarunB
 * @version 1.0 - 6-March-2018
 */
@RestController
@RequestMapping("/users")
public class UserController {

	private static final Logger log = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;

	@Autowired
	private EmailService emailService;

	/**
	 * get the user listing
	 * @author KarunaS
	 * @return ApiResponse
	 */
	@Secured({ Constant.ROLE_SUPER_ADMIN })
	@GetMapping
	public ApiResponse listUser() {
		log.info("UserController :: listUser() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, userService.findAll());
	}

	/**
	 * save register user
	 * 
	 * @author KarunaS
	 * @return ApiResponse
	 * @param user
	 */
	@PostMapping
	public ApiResponse create(@RequestBody UserDto user) {
		log.info("UserController :: create() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, userService.save(user));

	}

	/**
	 * get the user by id
	 * 
	 * @author KarunaS
	 * @return ApiResponse
	 * @param id
	 */
	@Secured({ Constant.ROLE_SUPER_ADMIN, Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@GetMapping(value = "/{id}")
	public ApiResponse getUser(@PathVariable int id) {
		log.info("UserController :: getUser() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, userService.findOne(id));
	}

	/**
	 * Method is used to get the user userName
	 * 
	 * @author KarunaS
	 * @return ApiResponse
	 * @param username
	 */
	@Secured({ Constant.ROLE_SUPER_ADMIN, Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@GetMapping(value = "/user/{username}")
	public ApiResponse getUserByEmail(@PathVariable String username) {
		log.info("UserController :: getUserByEmail() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, userService.findOne(username));
	}

	/**
	 * Method is used to send the mail fro forgot password
	 * 
	 * @author KarunaS
	 * @return string
	 * @param username
	 */
	@GetMapping(value = "/forgotPassword/{username}")
	public ApiResponse sendEmailForForgot(@PathVariable String username) {
		log.info("UserController :: sendEmailForForgot() started.");
		String result = emailService.sendEmailForForgot(username);
		log.info("UserController :: sendEmailForForgot() end.");
		return new ApiResponse(HttpStatus.OK, result.equals(Constant.SUCCESS) ? Constant.SUCCESS : Constant.FAILURE, result);
	}

	/**
	 * Method is used to change the password
	 * 
	 * @author KarunaS
	 * @return ApiResponse
	 * @param id
	 */
	@PostMapping(value = "/changePassword")
	public ApiResponse updatePassword(@RequestBody UserDto dto) {
		log.info("UserController :: changePassword() executed.");
		return new ApiResponse(HttpStatus.OK, userService.updatePassword(dto));
	}

	/**
	 * Method is used to update the user details
	 * 
	 * @author VarunB
	 * @return ApiResponse
	 * @param id
	 */
	@Secured({Constant.ROLE_SUPER_ADMIN, Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@RequestMapping(value = ("/update"), method = RequestMethod.POST)
	//@PostMapping(value = ("/update"), headers = "content-type=multipart/form-data")
	public @ResponseBody ApiResponse updateUserDetails(User user) {
		log.info("UserController :: updateUserDetails() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS,
				userService.updateDetails(user));
	}
	
	/**
	 * Method is used to change the password from dashboard
	 * 
	 * @author KarunaS
	 * @return ApiResponse
	 * @param id
	 */
	@Secured({Constant.ROLE_SUPER_ADMIN, Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@PostMapping(value = "/passwordChange")
	public ApiResponse passwordChange(@RequestBody UserDto dto) {
		log.info("UserController :: passwordChange() executed.");
		String result = userService.passwordChange(dto);
		String message = result.equals(Constant.INCORRECT_OLD_PASSWORD) ? Constant.FAILURE	: Constant.SUCCESS;
		return new ApiResponse(HttpStatus.OK, message, result);
	}

}
