/**
 * 
 */
package com.crelps.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.crelps.constant.Constant;
import com.crelps.dto.ApiResponse;
import com.crelps.dto.SavePropertyDto;
import com.crelps.dto.SortDto;
import com.crelps.service.PropertyService;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Class Information - This class is use for the fetch and save the all property details.
 * 
 * @author KarunaS
 * @version 1.0 - 27-March-2019
 */
@RestController
@RequestMapping("/property")
public class PropertyController {
	private static final Logger log = LoggerFactory.getLogger(PropertyService.class);

	@Autowired
	private PropertyService propertyService;

	/**
	 * This method is use to save property detail in to the data base
	 * 
	 * @param propertyImages- save property images
	 * @param propertyAttachments - save property Attachments
	 * @param savePropertyDto - save property details
	 * @return ApiResponse return the success message , HTTP status code and property details
	 * @throws IOException
	 * @author KarunaS
	 */
	@Secured({ Constant.ROLE_SUPER_ADMIN, Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@PostMapping
	public ApiResponse create(@RequestParam(value = "files", required = false) MultipartFile[] propertyImages,
			@RequestParam(value = "attachments", required = false) MultipartFile[] propertyAttachments,
			@RequestParam(value = "saveProperty", required = true) String savePropertyDto
			) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		SavePropertyDto saveProperty = mapper.readValue(savePropertyDto , SavePropertyDto.class);
		String message = propertyService.save(propertyAttachments, propertyImages, saveProperty);
		log.info("PropertyController :: create() executed.");
		return new ApiResponse(HttpStatus.OK, message);
	}


	/**
	 * This method is use for get the property data by propertyId
	 * 
	 * @date April 02, 2019
	 * @author karunaS
	 * @param id- get the property data by property id
	 * @return ApiResponse return the success message , HTTP status code and property details
	 */
	@GetMapping(value = "/getProperty/{propertyId}")
	public ApiResponse getPropertyById(@PathVariable int propertyId) {
		log.info("UserController :: getUserByEmail() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.findOne(propertyId));
	}


	/**
	 * This method is use for delete the property by propertyId
	 * 
	 * @date April 02, 2019
	 * @author karunaS
	 * @return ApiResponse return the success message , HTTP status code and property details
	 * @param id- delete the property data by property id
	 */
	@Secured({ Constant.ROLE_SUPER_ADMIN, Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@DeleteMapping(value = "/delete/{id}")
	public ApiResponse delete(@PathVariable(value = "id") int id) {
		log.info("PropertyController :: delete() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.delete(id));
	}

	/**
	 * This method is used to get all property type list from the data base
	 * 
	 * @author KarunaS
	 * @date April 03, 2019
	 * @param null
	 * @return ApiResponse return the success message , HTTP status code and property details
	 */
	@GetMapping(value = "/getPropertyType")
	public ApiResponse getPropertyTypeList() {
		log.info("PropertyController :: getPropertyTypeList() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.getPropertyTypeList());
	}

	/**
	 * This method is used to get all property Sub type list from the data base
	 * 
	 * @author KarunaS
	 * @date April 04, 2019
	 * @param typeId - find the data by the property type
	 * @return ApiResponse return the success message , HTTP status code and property details
	 */
	@GetMapping(value = "/getPropertySubType/{typeId}")
	public ApiResponse getPropertySubTypeList(@PathVariable(value = "typeId") int typeId) {
		log.info("PropertyController :: getPropertySubTypeList() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.getPropertySubTypeList(typeId));
	}

	/**
	 * Method to find get all property list based on property type, sort
     * category, sort type and page no
	 * 
	 * @author VarunB
	 * @param SortDto sortDto
	 * @return ApiResponse return the success message , HTTP status code and property details
	 */
	@Secured({ Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@PostMapping(value = "/getProperties")
	public ApiResponse getPropertiesByStatus(@RequestBody SortDto sortDto) {
		log.info("PropertyController :: getPropertiesByStatus() executed.");
	
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.getPropertiesByStatus(sortDto));
	}

	/**
	 * Method to post property or save property as draft
	 * 
	 * @author VarunB
	 * @param propertyId-get the property data by property id
	 * @return ApiResponse return the success and failure message , HTTP status code and property details
	 */
	@Secured({ Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@GetMapping(value = "/getProperties/{propertyId}")
	public ApiResponse postProperty(@PathVariable int propertyId) {
		log.info("PropertyController :: getPropertiesByStatus() executed.");
		return new ApiResponse(HttpStatus.OK, propertyService.postProperty(propertyId).equals(Constant.SUCCESS)
				? Constant.SUCCESS : Constant.FAILURE);
	}
	
	/**
	 * This method delete the property gallery by gallery id
	 * 
	 * @date April 26, 2019
	 * @author VarunB
	 * @param id - delete the gallery by id
	 * @return ApiResponse return the success message , HTTP status code and property details
	 */
	@Secured({ Constant.ROLE_SUPER_ADMIN, Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@DeleteMapping(value = "/deleteGallery/{id}")
	public ApiResponse deleteGallery(@PathVariable(value = "id") int id) {
		log.info("PropertyController :: deleteGallery() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.deleteGallery(id));
	}
	
	/**
	 * This method is use for delete the property attachment by attachment id
	 * 
	 * @date April 26, 2019
	 * @author VarunB
	 *  @param delete the attachment by id
	 * @return ApiResponse return the success message , HTTP status code and property details
	 */
	@Secured({ Constant.ROLE_SUPER_ADMIN, Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@DeleteMapping(value = "/deleteAttachment/{id}")
	public ApiResponse deleteAttachment(@PathVariable(value = "id") int id) {
		log.info("PropertyController :: deleteAttachment() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.deleteAttachment(id));
	}
	
	/**
	 * Method is Method to add property attachment description by id
	 * 
	 * @author VarunB
	 * @param int attachmentId
	 * @param String attachementDescription
	 * @return ApiResponse return the success message , HTTP status code and property details
	 */
	@Secured({ Constant.ROLE_BROKER, Constant.ROLE_OWNER })
	@GetMapping(value = "/renameAttachment")
	public ApiResponse renameAttachment(@RequestParam int attachmentId, @RequestParam String attachementDescription) {
		log.info("PropertyController :: renameAttachment() executed.");
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.renameAttachment(attachmentId,attachementDescription));
	}
	
	
	 /**
     * This Method is used to find to get all property type list
     * 
     * @author KarunaS
     * @date May 07, 2019
     * @param saleLeaseType
     * @return PropertyType list data
     */
    @GetMapping(value = "/getType/{saleLeaseType}")
    public ApiResponse getPropertyTypeListBySaleLease(@PathVariable(value = "saleLeaseType") String saleLeaseType) {
        log.info("PropertyController :: getPropertyTypeListBySaleLease() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.getPropertyTypeListBySaleLease(saleLeaseType));
    }
    

	
	
	 /**
     * Method is used to find get all state list
     * 
     * @author KarunaS
     * @date June 15, 2019
     * @return ApiResponse return the success and failure message , HTTP status code and property details
     */
   @GetMapping(value = "/getState")
    public ApiResponse getStateList() {
        log.info("PropertyController :: getStateList() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.getStateList());
    }

	
	/**
	 * Method is used to get all property type and sub type
	 * 
	 * @author VarunB
	 * @param null - 
	 * @return ApiResponse return the success message , HTTP status code and property details
	 */
	@GetMapping(value = "/getPropertyTypeAndSubtype")
	public ApiResponse getPropertyTypeAndSubTypeList() {
		log.info("PropertyController :: getPropertyTypeList() executed.");
		
		return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, propertyService.getPropertyTypeAndSubTypeList());
	}
}
