package com.crelps.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.crelps.service.UserService;

/**
 * Class Information - This class is use for the home controller
 * 
 * @author VarunB
 * @version March 10, 2019
 */
@Controller
public class HomeController {

	private static final Logger log = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	private UserService userService;

	@Autowired
	private Environment env;

	/**
	 * his method is user for Verify the user email and send the filled data to user email.
	 * 
	 * @author VarunB
	 * @date March 10, 2019
	 * @return String - return the string type front end url
	 * @param username - verify email by user name
	 */
	@GetMapping(value = "/verify/{username}")
	public String getEmailVerification(@PathVariable String username) {
		log.info("HomeController :: getEmailVerification() executed.");
		userService.verifyEmail(username);
		return "redirect:" + env.getProperty("front.end.url");
	}
}
