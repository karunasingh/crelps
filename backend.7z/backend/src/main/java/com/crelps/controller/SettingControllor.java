/**
 * 
 */
package com.crelps.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crelps.config.Translator;
import com.crelps.constant.Constant;
import com.crelps.dto.ApiResponse;
import com.crelps.dto.UserSortDto;
import com.crelps.model.Settings;
import com.crelps.model.User;
import com.crelps.service.PropertyService;
import com.crelps.service.SettingService;
import com.crelps.service.UserService;

/**
 * Class Information - This class is use for the controller
 * 
 * @author KarunaS
 * @version 1.0 - 20-May-2019
 */
@RestController
@RequestMapping("/setting")
public class SettingControllor {
    private static final Logger log = LoggerFactory.getLogger(PropertyService.class);
    
    @Autowired
    private SettingService settingService;
    
    @Autowired
    private UserService userService;

    /**
     * save super Admin details
     * 
     * @author KarunaS
     * @return ApiResponse
     * @param settings
     */
    @PostMapping
    public ApiResponse create(@RequestBody Settings settings) {
        log.info("SettingControllor :: create() executed.");
        //return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, settingService.save(settings));
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, settingService.save(settings));
    }
    
    /**
     * fetch the list of setting details
     * @date May 23, 20
     * @author KarunaS
     * @return ApiResponse
     */
    @GetMapping(value = "/get")
    public ApiResponse getSettingData() {
        log.info("SettingControllor :: listUser() executed.");
        return new ApiResponse(HttpStatus.OK, Translator.toLocale("lang.success"), settingService.getSettingData());
    }
    
    /**
     * fetch the user details by status
     * @date May 23, 20
     * @author KarunaS
     * @return ApiResponse
     */
    @GetMapping
    public ApiResponse listUser() {
        log.info("SettingControllor :: listUser() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, settingService.findByStatus());
    }
    
    /**
     * delete the user by id
     * 
     * @date May 21, 2019
     * @author karunaS
     * @return ApiResponse
     * @param id
     */
    @DeleteMapping(value = "/delete/user/{id}")
    public ApiResponse delete(@PathVariable(value = "id") int id) {
        log.info("SettingControllor :: delete() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, settingService.delete(id));
    }
    
    /**
     * Method is used to update the User
     * 
     * @date May 22, 2019
     * @author KarunaS
     * @return ApiResponse
     * @param user
     */
    @PostMapping(value = "/update/user")
    public ApiResponse updateUser(@RequestBody User user) {
        log.info("SettingControllor :: updateProperty() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, settingService.updateUser(user));
    }

    /**
     * get the user by id
     * @date May 23, 2019
     * @author KarunaS
     * @return ApiResponse
     * @param id
     */
    @GetMapping(value = "/{id}")
    public ApiResponse getUser(@PathVariable int id) {
        log.info("SettingControllor :: getUser() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, userService.findOne(id));
    }
    
    
    /**
     * Method is used to find get all properties list
     * 
     * @author karunaS
     * @param sortDto
     * @return ApiResponse
     */
    @PostMapping(value = "/getUserList")
    public ApiResponse getUserByStatus(@RequestBody UserSortDto userSortDto) {
        log.info("PropertyController :: getPropertiesByStatus() executed.");
 
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, settingService.getUserByStatus(userSortDto));
    }
    
    //@Secured({ Constant.ROLE_SUPER_ADMIN, Constant.ROLE_BROKER, Constant.ROLE_OWNER })
    @GetMapping(value = "/user/{username}")
    public ApiResponse getUserByEmail(@PathVariable String username) {
        log.info("UserController :: getUserByEmail() executed.");
        return new ApiResponse(HttpStatus.OK, Constant.SUCCESS, userService.findOne(username));
    }
}
