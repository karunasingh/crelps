package com.crelps.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crelps.dto.ApiResponse;
import com.crelps.dto.ContactDto;
import com.crelps.service.EmailService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

/**
 * Class Information - This class is use for the contact information
 * 
 * @author KarunaS
 * @date 09-March-2019
 */
@RestController
@RequestMapping("/contact")
public class ContactController {

	private static final Logger log = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	private EmailService emailService;
	
	/**
	 * This method is user for Verify the user email and send the filled data to user email.
	 * 
	 * @author VarunB
	 * @date March 10, 2019
	 * @return ApiResponse return the success message , HTTP status code and contact dto type details
	 * @param  ContactDto contactDto
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	@PostMapping
	public ApiResponse postQuestion(ContactDto contactDto) throws JsonParseException, JsonMappingException, IOException {
		log.info("ContactController :: postQuestion() executed.");
		return new ApiResponse(HttpStatus.OK, emailService.sendContactEmail(contactDto));
	}
}
