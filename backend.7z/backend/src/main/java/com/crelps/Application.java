/**
 * ===========================================================================
 * File Name Application.java
 *
 * Created on 05-March-2019
 *
 * This code contains copyright information which is the proprietary property
 * of crelps. No part of this code may be reproduced, stored or transmitted
 * in any form without the prior written permission of crelps.
 *
 * Copyright (C) crelps. 2019
 * All rights reserved.
 *
 * Modification history:
 * $Log: Application.java,v $
 * ===========================================================================
 */

package com.crelps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.CrossOrigin;
/**
 * Class Information - This class is used for the main method
 *
 * @author KarunaS
 * @version 1.0 - 5-March-2018
 */
@CrossOrigin
@SpringBootApplication
@PropertySource("classpath:email.properties")
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
