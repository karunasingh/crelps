/**
 * 
 */
package com.crelps.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crelps.config.Translator;
import com.crelps.dao.SettingDao;
import com.crelps.dao.UserDao;
import com.crelps.dto.UserSortDto;
import com.crelps.model.Settings;
import com.crelps.model.User;
import com.crelps.service.SettingService;

/**
 * Class Information - This class is user for the business logic
 * 
 * @author KarunaS
 * @version 1.0 - 20-May-2019
 */
@Transactional
@Service(value = "settingService")
public class SettingServiceImpl implements SettingService {
    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private SettingDao settingDao;

    @Autowired
    private UserDao userDao;
    
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;


    /**
     * @author KarunaS
     * @date May 20, 2019
     * @return settings
     * @param settings
     * @description save super Admin details data in data base
     */

    @Override
    public Settings save(Settings settings) {
        log.info("SettingServiceImpl :: save() method start.");
        List<Settings> settingsDaetail = settingDao.findAll();        
        try {
            for (Settings settings2 : settingsDaetail) {
                
                if (settings2.getSettingsId() != 0 && settings2.getPricePerProperty() != settings.getPricePerProperty()) {
                    settings2.setPricePerProperty(settings.getPricePerProperty().replaceAll(",", "").replace("$", ""));
                    settings2.setPromotional(settings.isPromotional());
                    settingDao.save(settings2);
                } 
            }           
            if(settingsDaetail.size()==0) {
                settings.setPricePerProperty(settings.getPricePerProperty().replaceAll(",", "").replace("$", ""));
                settingDao.save(settings);
            }
        } catch (Exception e) {
            log.info("Error in SettingServiceImpl :: save() method.", e);
        }
        log.info("SettingServiceImpl :: save() method end.");
        return settings;
    }
    
    /**
     * @author KarunaS
     * @date May 30, 2019
     * @return Message
     * @param user
     * @description get the Settings
     */
    @Override
      public Settings getSettingData() 
    { 
      log.info("SettingServiceImpl :: getUserByStatus() method started.");
      Settings settings = settingDao.findAll().get(0);
     log.info("SettingServiceImpl :: getUserByStatus() method end.");
     return settings; 
     }
     
    /**
     * @author KarunaS
     * @date May 23, 2019
     * @return Message
     * @param user
     * @description get the all user list by status
     */
    @Override
    
      public List<User> findByStatus() 
    { 
      log.info("SettingServiceImpl :: getUserByStatus() method started.");
      List<User> user = new ArrayList<>();
      boolean status = true; 
      //user = userDao.findByStatus(status);
     log.info("SettingServiceImpl :: getUserByStatus() method end."); 
     return user; 
     }
     
  /*  public List<UserDtoResult> findByStatus() {
        log.info("SettingServiceImpl :: getUserByStatus() method started.");
        List<User> user = new ArrayList<>();
        boolean status = true;
        List<UserDTOTest> temp = userDao.findStatus(status);

        List<UserDtoResult> tempReturn = new ArrayList<>();
        for (UserDTOTest userDTOTest : temp) {
            UserDtoResult userDto = new UserDtoResult();
            System.out.println("getUserId===" + userDTOTest.getFirstName());
            // userDto.setUserId(userDTOTest.getUserId());
            userDto.setFirstName(userDTOTest.getFirstName());
            userDto.setLastName(userDTOTest.getLastName());
            userDto.setUsername(userDTOTest.getUsername());
            tempReturn.add(userDto);

        }
        log.info("SettingServiceImpl :: getUserByStatus() method end.");
        return tempReturn;
    }
*/
    /**
     * @author KarunaS
     * @date May 22, 2019
     * @return Message
     * @param user
     * @description update the user
     */
    @Override
    public String updateUser(User user) {
        log.info("SettingServiceImpl :: updateUser() method strated.");
        User userData = userDao.findById(user.getUserId());
        try {
            if (userData.getUserId() != 0) {
                userData.setFirstName(user.getFirstName());
                userData.setLastName(user.getLastName());
                userData.setUsername(user.getUsername());
                userData.setPassword(passwordEncoder.encode(String.valueOf(user.getPassword())));
                userData.setModifiedBy(userData.getUserId());
                userData.setModifiedDate(new Date());
                userData.setModifiedBy(userData.getUserId());
                userData.setModifiedDate(new Date());
                userDao.save(userData);
            }
        } catch (Exception e) {
            log.info("Error in update user :: updateUser() method.", e);
        }
        log.info("SettingServiceImpl :: updateUser() method end.");
        return Translator.toLocale("lang.User.Updated");
    }

    /**
     * Method to delete a User based on user id
     * 
     * @date May 21, 2019
     * @param id
     * @return message
     * @author karunaS
     */
    @Override
    public String delete(int id) {
        userDao.findById(id).setStatus(false);
        return Translator.toLocale("lang.User.Deleted");
    }

    
    /**
     * Method to find get all property list based on property type, sort
     * category, sort type and page no
     * 
     * @author karunaS
     * @param userSortDto
     * @date 10-June-2019
     * @return list of property by userSortDto parameters
     */
    @Override
    public List<User> getUserByStatus(UserSortDto userSortDto) {
        log.info("SettingServiceImpl :: getUserByStatus() method started.");
        List<User> user = new ArrayList<>();
        PageRequest pageRequest = null;
       if (userSortDto.getSortCategory() != null && !userSortDto.getSortCategory().isEmpty()) {
            String str[] = userSortDto.getSortCategory().split("-");
            userSortDto.setSortCategory(str[0]);
            if (str[1].equalsIgnoreCase("asc")) {
                pageRequest = PageRequest.of(userSortDto.getPageNo(), userSortDto.getMaxElements(),
                        Sort.by(userSortDto.getSortCategory()).ascending());
            } else {
                pageRequest = PageRequest.of(userSortDto.getPageNo(), userSortDto.getMaxElements(),
                        Sort.by(userSortDto.getSortCategory()).descending());
            }
        }
        if (userSortDto.getRole() != null && !userSortDto.getRole().isEmpty()) {
                 user = userDao.findByRoleAndStatus(userSortDto.getRole(), pageRequest);
               if (user != null && !user.isEmpty()) {
//                    user.get(0).setTotalCount(userDao.countByStatus());
                    user.get(0).setOwnerCount(userDao.countByStatusAndRole("owner"));
                    user.get(0).setBrokerCount(userDao.countByStatusAndRole("broker"));
                }
            } 
      else {
            user = userDao.findByStatus(pageRequest);
            user.get(0).setTotalCount(userDao.countByStatus());
            user.get(0).setOwnerCount(userDao.countByStatusAndRole("owner"));
            user.get(0).setBrokerCount(userDao.countByStatusAndRole("broker"));           
        }
        log.info("SettingServiceImpl :: getUserByStatus() method end.");
        return user;
    }


}
