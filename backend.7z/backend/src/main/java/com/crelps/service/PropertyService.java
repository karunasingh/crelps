/**
 * 
 */
package com.crelps.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.crelps.dto.PropertyDto;
import com.crelps.dto.PropertyTypeDto;
import com.crelps.dto.SavePropertyDto;
import com.crelps.dto.SortDto;
import com.crelps.dto.StateDto;
import com.crelps.model.Property;
import com.crelps.model.PropertySubType;
import com.crelps.model.PropertyType;

/**
 * Class Information - This class is use for service methods
 * 
 * @author KarunaS
 * @version 1.0 - 27-March-2019
 */
public interface PropertyService {

	/**
	 * This method is use to save property detail in to the data base
	 * @author VarunB
	 * @param propertyAttachments - save property Attachments
	 * @param propertyImages - save property images
	 * @param saveProperty save property details
	 * @return string type propertyAttachments,propertyImages,saveProperty
	 */
	String save(MultipartFile[] propertyAttachments, MultipartFile[] propertyImages, SavePropertyDto saveProperty);

	/**
     * This method is use for get the property data by propertyId
     * 
     * @author karunaS
     * @param id- get the property data by property id
     * @return return property type dto
     */
	PropertyDto findOne(int id);

	/**
     * This method is use for delete the property by propertyId
     * 
     * @author karunaS
     * @param id- delete the property data by property id
     * @return string type message
     */
	public String delete(int id);


	/**
     * This method is used to get all property type list from the data base
     * 
     * @author KarunaS
     * @param null
     * @return list of property type dto
     */
	List<PropertyTypeDto> getPropertyTypeList();

    /**
     * This method is used to get all property Sub type list from the data base
     * 
     * @author KarunaS
     * @param typeId - find the data by the property type
     * @return list of property sub type 
     */
	List<PropertySubType> getPropertySubTypeList(int typeId);

	/**
	 * Method to find get all property list based on sortDto
	 * 
	 * @author VarunB
	 * @param sortDto
	 * @return list of properties by sortDto parameters
	 */
	List<PropertyDto> getPropertiesBySort(SortDto sortDto);

	/**
	 * Method to find get all property list based on property type, sort
	 * category, sort type and page no
	 * 
	 * @author VarunB
	 * @param sortDto
	 * @return list of property by sortDto parameters
	 */
	List<Property> getPropertiesByStatus(SortDto sortDto);


	/**
     * This method is used to find get all properties list 
     * 
     * @author VarunB
     * @param propertyId-get the property data by property id
     * @return string type message
     */
	String postProperty(int id);

	
	/**
     * Method to is use for find the property based on id
     * 
     * @author KarunaS
     * @param property id
     * @return property data
     */
	Property findPropertyById(int propertyId);

	/**
     * This method delete the property gallery by gallery id
     * 
     * @author VarunB
     * @param id - delete the gallery by id
     * @return string type success message 
     */
	public String deleteGallery(int id);
	
	/**
     * This method is use for delete the property attachment by attachment id
     * 
     * @author VarunB
     * @param delete the attachment by id
     * @return string type success message 
     */
	public String deleteAttachment(int id);
	
	 /**
     * Method to add property attachment description by id
     * 
     * @author VarunB
     * @param int attachmentId
     * @param String attachementDescription
     * @return string type success message 
     */
	public String renameAttachment(int attachmentId,String attachementDescription);
	

	 /**
     * This Method is used to find to get all property type list
     * 
     * @author KarunaS
     * @param saleLeaseType
     * @return PropertyType list data
     */
    List<PropertyType> getPropertyTypeListBySaleLease(String saleLeaseType);

    /**
     * Method to get the state list
     * 
     * @param null
     * @return state dto list
     * @author KarunaS
     */
    List<StateDto> getStateList();

    /**
	 * This method is used for get the property type and sub type list
     * @author VarunB
     * @return  propertyTypeDto list
     */
	List<PropertyTypeDto> getPropertyTypeAndSubTypeList();
}
