package com.crelps.service;

import com.crelps.dto.UserCompanyDto;

/**
 * Class Information - This class is used for maintaining the controller
 *
 * @author VarunB
 * @version 1.0 - 20-March-2018
 */
public interface UserCompanyService {
	/**
	 * This method is user for save the company details into data base
	 * @author varunB
	 * @param userCompany
	 * @param id
	 */
	UserCompanyDto save(UserCompanyDto userCompany, int id);

	/**
	 * This method is user for update company logo based on id
	 * @author varunB
	 * @param id - updae based on id
	 * @param userCompany
	 * @return message
	 */
	public String update(UserCompanyDto userCompanyDto, int id);

	/**
	 * This method is user for delete the company logo
	 * @author varunB
	 * @param id - delete based on id
	 * @return message
	 */
	public String delete(int id);

}
