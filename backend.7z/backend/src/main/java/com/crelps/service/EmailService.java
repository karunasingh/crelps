package com.crelps.service;

import com.crelps.dto.ContactDto;
import com.crelps.model.User;

/**
 * Class Information - This class is use for service methods
 * 
 * @author KarunaS
 * @version 1.0 - 15-May-2019
 */
public interface EmailService {
	
	/**
	 * This method is use for send the email to the user for the forgot password
     * @author karunaS
     * @param userName - email send based on userNmae
     * @return string
     */
    public String sendEmailForForgot(String username);
    
    /**
     * This method is use for send the email to user for new Register
     * @author varunB
     * @param user - user type entity
     * @param null
     */
    public void sendNewRegisterEmail(User user);
    
    /**
     * This method is use for to send the contact details
     * @author KarunaS
     * @param contactDto - contact type dto
     * @return string
     */
    public String sendContactEmail(ContactDto contactDto);

}
