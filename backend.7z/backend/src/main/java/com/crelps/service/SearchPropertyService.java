/**
 * 
 */
package com.crelps.service;

import java.util.List;

import com.crelps.dto.SearchPropertyDto;
import com.crelps.model.Property;

/**
 * Class Information - This class is user for the service
 * 
 * @author KarunaS
 * @version 1.0 - 01-May-2019
 */
public interface SearchPropertyService {

	/**
	 * This method is use to get property list for searching
	 * 
	 * @author KarunaS
	 * @param SearchPropertyDto based on propertyTypeId,propertyStatus,searchFieldVal
	 * @return property list 
	 */
	List<Property> serachProperty(SearchPropertyDto search);

}
