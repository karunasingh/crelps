
package com.crelps.service;

import java.util.List;

import com.crelps.dto.MenuDto;

/**
 * Class Information - This class is user for the service method
 * 
 * @author KarunaS
 * @version 1.0 - 27-March-2019
 */
public interface RolePermissionService {

    /**
     * This method use for get the all menu list based on role id
     * @author KarunaS
     * @param roleId - get the menu list based on roleid
     * @return menu list type dto
     */
    List<MenuDto> getMenuList(int rioeId);
}
