/**
 * 
 */
package com.crelps.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crelps.dao.BillingDao;
import com.crelps.model.Billing;
import com.crelps.service.BillingService;

/**
 * Class Information - This class is use for business logic
 * 
 * @author KarunaS
 * @version 1.0 - 24-May-2019
 */

@Transactional
@Service(value = "billingService")
public class BillingServiceImpl implements BillingService{
    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
    
    @Autowired
    BillingDao billingDao;
    /**
     * @author KarunaS
     * @date May 24, 2019
     * @return billing
     * @param billing
     * @description save billing details data in data base
     */
    @Override
    public Billing save(Billing billing) {
        log.info("BillingServiceImpl :: save() method start.");
        try {
            billing.setValidThruDate(billing.getMonth()+"/"+billing.getYear());
            billingDao.save(billing);
        } catch (Exception e) {
            log.info("Error in BillingServiceImpl :: save() method.", e);
        }
        log.info("BillingServiceImpl :: save() method end.");
        return billing;
    }

}
