package com.crelps.service.impl;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.crelps.service.AuthenticationFacadeService;

/**
 * Class Information - This class is user for token Authentication
 * 
 * @author NiteshD
 * @version 1.0 - 3-March-2019
 */
@Component
public class AuthenticationFacadeServiceImpl implements AuthenticationFacadeService {

    
    /**
     * This method is use for token Authentication
     * 
     * @author VarunB
     * @date April 10, 2019
     * @author NiteshD
     * @param null
     * @return Authentication type security
     */
	@Override
	public Authentication getAuthentication() {
		return SecurityContextHolder.getContext().getAuthentication();
	}
}
