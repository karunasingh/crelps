package com.crelps.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.crelps.config.Translator;
import com.crelps.constant.Constant;
import com.crelps.dao.UserDao;
import com.crelps.dto.ContactDto;
import com.crelps.exception.UserDoesNotExistException;
import com.crelps.model.User;
import com.crelps.service.EmailService;
import com.crelps.util.CommonUtil;
/**
 * Class Information - This class is user for to send the email 
 * 
 * @author VarunB
 * @version 1.0 - 15-April-2019
 */
@Service("emailService")
public class EmailServiceImpl implements EmailService {

	private static final Logger log = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	ResourceLoader resourceLoader;

	@Autowired
	private Environment env;

	@Autowired
	private UserDao userDao;

	/**
	 * Method is used to send email
	 * 
	 * @author niteshD
	 * @param username
	 * @param content
	 * @param subject
	 */
	private void mailSend(InternetAddress[] username, String content, String subject) {
		log.info("EmailServiceImpl :: mailSend() method started");
		Properties props = new Properties();
		props.put("mail.smtp.auth", env.getProperty("spring.mail.properties.mail.smtp.auth"));
		props.put("mail.smtp.starttls.enable", env.getProperty("spring.mail.properties.mail.smtp.starttls.enable"));
		props.put("mail.smtp.host", env.getProperty("spring.mail.host"));
		props.put("mail.smtp.port", env.getProperty("spring.mail.port"));
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(env.getProperty("spring.mail.username"),
						env.getProperty("spring.mail.password"));
			}
		});
		Message message = new MimeMessage(session);
		try {
			message.setFrom(new InternetAddress(env.getProperty("spring.mail.username")));
			message.setRecipients(Message.RecipientType.TO, username);
			message.setSubject(subject);
			message.setContent(content, "text/html");
			Transport.send(message);
		} catch (Exception e) {
			log.info("Error in EmailServiceImpl :: mailSend() method", e);
		}
		log.info("EmailServiceImpl :: mailSend() method end");
	}

	/**
	 * This method is used for send email to the user while register
	 * @author VarunB
	 * @date March 14, 2019
	 * @param user
	 * 
	 */
	@Override
	public void sendNewRegisterEmail(User user) {
		log.info("EmailServiceImpl :: sendNewRegisterEmail() method started");
		InputStream inputStream = null ;
		BufferedReader reader = null;
		try {
			StringBuilder stringBuilder = new StringBuilder();

			 inputStream = resourceLoader.getResource("classpath:templates/registerTemplate.html")
					.getInputStream();

			 reader = new BufferedReader(new InputStreamReader(inputStream));
			String line;
			while ((line = reader.readLine()) != null) {
			    stringBuilder.append(line);
			}
	
			String content = stringBuilder.toString();
			content = content.replaceAll("userDetails", user.getFirstName() + " " + user.getLastName());
			content = content.replaceAll("verifyEmailUrl",
					env.getProperty("api.url") + "verify/" + CommonUtil.encoder(user.getUsername()));

			mailSend(InternetAddress.parse(user.getUsername()), content,
			    Translator.toLocale("lang.register.email.subject"));
		} catch (Exception e) {
			log.info("Error in EmailServiceImpl :: sendEmail() method", e);
		}finally {
		    try {
		        if(inputStream!=null && reader!=null){
                inputStream.close();
                reader.close(); 
		        }
            } catch (IOException e) {
                log.error("Error in finally block :: sendEmail() method", e);
            }
		   
        }
		log.info("EmailServiceImpl :: sendNewRegisterEmail() method end");
	}

	/**
	 * @author VarunB
	 * @date March 14, 2019
	 * @return Message
	 * @param username
	 * @description send email to change the password
	 */
	@Override
	public String sendEmailForForgot(String username) {
		log.info("EmailServiceImpl :: sendEmailForForgot() method started");
		String msg = "";
		InputStream inputStream = null;
		BufferedReader reader = null;
		try {
			StringBuilder stringBuilder = new StringBuilder();

			 inputStream = resourceLoader.getResource("classpath:templates/forgotTemplate.html")
					.getInputStream();

			 reader = new BufferedReader(new InputStreamReader(inputStream));
			String line;
			while ((line = reader.readLine()) != null) {
			    stringBuilder.append(line);
			}

			String content = stringBuilder.toString();
			User user = userDao.findByUsername(username);
			if (user == null) {
				throw new UserDoesNotExistException("User does not exist");
			} else {
				content = content.replaceAll("UserName", user.getFirstName() + " " + user.getLastName());
				content = content.replaceAll("emailAddress", user.getUsername());
				content = content.replaceAll("changePasswordUrl", env.getProperty("front.end.url")
						+ "/#/reset-password/" + CommonUtil.encoder(user.getUsername()));

				mailSend(InternetAddress.parse(username), content,
						 Translator.toLocale("lang.forgot.password.email.subject"));
				msg = Constant.SUCCESS;
			}
		} catch (Exception e) {
			log.error("ForgotPassController :: Mail Exception in passLink()", e);
			return Constant.FAILURE;
		}finally {
            try {
                if(inputStream!=null && reader!=null){
                inputStream.close();
                reader.close(); 
                }
            } catch (IOException e) {
                log.error("Error in finally block :: sendEmailForForgot() method", e);
            }
           
        }
		log.info("EmailServiceImpl :: sendEmailForForgot() method end");
		return msg;
	}

	/**
	 * This method is used for send the email while send email for contact
	 * @author KarunaS
	 * @date May 15, 2019
	 * @param contactDto
	 * @return String message
	 */
	@Override
	public String sendContactEmail(ContactDto contactDto) {
		log.info("EmailServiceImpl :: sendContactEmail() method started");
		InputStream inputStream = null;
        BufferedReader reader = null;
		try {
			StringBuilder stringBuilder;
			String template[] ={"contactServerTemplate","contactUserTemplate"};
			String email[] ={env.getProperty("spring.mail.username"),contactDto.getEmail()};
			for(int i=0 ;i<2;i++){
			    stringBuilder = new StringBuilder();
			 inputStream = resourceLoader.getResource("classpath:templates/"+template[i]+".html")
					.getInputStream();

			 reader = new BufferedReader(new InputStreamReader(inputStream));
			String line;
			while ((line = reader.readLine()) != null) {
			    stringBuilder.append(line);
			}
			String content = stringBuilder.toString();
			contactDto.setFirstName(contactDto.getFirstName()!=null?contactDto.getFirstName():"");
			contactDto.setLastName(contactDto.getLastName()!=null?contactDto.getLastName():"");
			contactDto.setEmail(contactDto.getEmail()!=null?contactDto.getEmail():"");
			contactDto.setPhone(contactDto.getPhone()!=null?contactDto.getPhone():"");
			contactDto.setComment(contactDto.getComment()!=null?contactDto.getComment():"");
			content = content.replaceAll("firstName", contactDto.getFirstName());
			content = content.replaceAll("lastName", contactDto.getLastName());
			content = content.replaceAll("email", contactDto.getEmail());
			content = content.replaceAll("phone", contactDto.getPhone());
			content = content.replaceAll("description", contactDto.getComment());

			mailSend(InternetAddress.parse(email[i]), content, Translator.toLocale("lang.contact.email.subject"));
			}
			log.info("EmailServiceImpl :: sendContactEmail() method end");
			return Constant.SUCCESS;
		} catch (Exception e) {
			log.info("Error in EmailServiceImpl :: sendContactEmail() method", e);
			return Constant.FAILURE;
		}finally {
            try {
                if(inputStream!=null && reader!=null){
                inputStream.close();
                reader.close(); 
                }
            } catch (IOException e) {
                log.error("Error in finally block :: sendContactEmail() method", e);
            }
           
        }
		
	}
}
