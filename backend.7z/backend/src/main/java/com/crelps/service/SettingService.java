/**
 * 
 */
package com.crelps.service;

import java.util.List;

import com.crelps.dto.UserSortDto;
import com.crelps.model.Settings;
import com.crelps.model.User;

/**
 * Class Information - This class is is use for service methods
 * 
 * @author KarunaS
 * @version 1.0 - 20-May-2019
 */
public interface SettingService {

    /**
     * This method is use for save the setting data in the data base
     * @author KarunaS
     * @param settings - save the setting parameters data
     * @return settings details
     */
    Settings save(Settings settings);
    
    /**
     * This method is use for for delete the user
     * @param id
     * @return message
     * @author karunaS
     */
    public String delete(int id);


    /**
     * This method is use for update the user
     * @param user
     * @return message
     * @author karunaS
     */
    String updateUser(User user);

    /**
     * This method is use for get the user list by status
     * 
     * @author karunaS
     * @return User list
     */
    List<User> findByStatus();

    /**
     * This method is use for get setting data from the data base
     * @author karunaS
     * @return setting data
     */
    Settings getSettingData();

    
    /**
     * This method is use for get the user list by status
     * @author karunaS
     * @return User list
     */
    List<User> getUserByStatus(UserSortDto userSortDto);

}
