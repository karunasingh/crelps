package com.crelps.service;

import org.springframework.security.core.Authentication;

/**
 * Class Information - This class is use for service interfaces
 * 
 * @author NiteshD
 * @version 1.0 - 26-March-2019
 */
public interface AuthenticationFacadeService {

    /**
     * This method is used for authentication
     * @author NiteshD
     * @param null
     * @return authentication type
     */
    Authentication getAuthentication();
}
