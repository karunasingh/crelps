/**
 * 
 */
package com.crelps.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crelps.dao.SearchPropertyDao;
import com.crelps.dto.SearchPropertyDto;
import com.crelps.model.Property;
import com.crelps.service.SearchPropertyService;

/**
 * Class Information - This class is use for the controller
 * 
 * @author KarunaS
 * @version 1.0 - 24-April-2019
 */
@Transactional
@Service(value = "searchPropertyService")
public class SearchPropertyServiceImpl implements SearchPropertyService {
	
	private static final Logger log = LoggerFactory.getLogger(SearchPropertyServiceImpl.class);
	
	@Autowired
	private SearchPropertyDao searchPropertyDao;

	/**
	 * Method to get property from the data base
	 * 
	 * @author karunaS
	 * @param property
	 *            id
	 * @return success or failure message
	 */
	@Override
	public List<Property> serachProperty(SearchPropertyDto search) {
		log.info("SearchPropertyServiceImpl :: serachProperty() method start.");
		return searchPropertyDao.findSaleProperties(search.propertyStatus,  search.searchFieldVal,  search.city,  search.state,  search.zipcode,  search.tenancy,  search.minCapRate,  search.maxCapRate,  search.minLotSize,  search.maxLotSize,  search.minSalePrice,  search.maxSalePrice,  search.minYearBuilt,  search.maxYearBuilt,  search.subTypeId,  search.minBuildingSize,  search.maxBuildingSize);
	}
}
