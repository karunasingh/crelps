/**
 * 
 */
package com.crelps.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.crelps.config.Translator;
import com.crelps.constant.Constant;
import com.crelps.dao.PropertyAttachmentDao;
import com.crelps.dao.PropertyDao;
import com.crelps.dao.PropertyGalleryDao;
import com.crelps.dao.PropertySubTypeDao;
import com.crelps.dao.PropertyTypeDao;
import com.crelps.dao.StateDao;
import com.crelps.dao.UserDao;
import com.crelps.dto.PropertyDto;
import com.crelps.dto.PropertyTypeDto;
import com.crelps.dto.SavePropertyDto;
import com.crelps.dto.SortDto;
import com.crelps.dto.StateDto;
import com.crelps.model.Property;
import com.crelps.model.PropertyAttachement;
import com.crelps.model.PropertyDetails;
import com.crelps.model.PropertyGallery;
import com.crelps.model.PropertySubType;
import com.crelps.model.PropertyType;
import com.crelps.model.User;
import com.crelps.service.PropertyService;
import com.crelps.util.FileUtil;
import com.crelps.util.ImageUtil;
import com.crelps.util.LocationUtil;

/**
 * Class Information - This class is user for the business logic implementation
 * 
 * @author KarunaS
 * @version 1.0 - 27-March-2019
 */
@Transactional
@Service(value = "propertyService")
public class PropertyServiceImpl implements PropertyService {
	private static final Logger log = LoggerFactory.getLogger(PropertyServiceImpl.class);

	@Autowired
	private PropertyDao propertyDao;

	@Autowired
	private UserDao userDao;

	@Autowired
	private PropertyTypeDao propertyTypeDao;

	@Autowired
	private PropertySubTypeDao propertySubTypeDao;

	@Autowired
	private PropertyGalleryDao propertyGalleryDao;

	@Autowired
	private PropertyAttachmentDao propertyAttachmentDao;
	
	@Autowired
    private StateDao stateDao;


	/**
	 * save the added property data in data base
	 * 
	 * @author VarunB
	 * @date April 22, 2019
	 * @param propertyAttachments- save property Attachments
	 * @param propertyImages- save property images
	 * @param savePropertyDto -save property details
	 * @param defaultImageName
	 * @param editImage
	 * @param editAttachment
	 * @return property
	 * @author KarunaS
	 * 
	 */	
	@Override
	public String save(MultipartFile[] propertyAttachments, MultipartFile[] propertyImages,
			SavePropertyDto savePropertyDto) {
		log.info("PropertyServiceImpl :: save() method start.");
		Property property = savePropertyDto.getProperty();
		PropertyAttachement propertyAttachment;
		PropertyGallery propertyGallery;
		String fileName;
		try {
			String editAttachment = savePropertyDto.getEditAttachment();
			String editImage = savePropertyDto.getEditImage();
			String defaultImageName = savePropertyDto.getDefaultImageName();
			int galleryId = savePropertyDto.getGalleryId();

			PropertyGallery newDefaultImageDetail = null;
			if (galleryId > 0) {
				newDefaultImageDetail = propertyGalleryDao.findById(galleryId).get();
				property.setDefaultImagePath(newDefaultImageDetail.getImagePath());
				property.setThumbnailImagePath(newDefaultImageDetail.getThumbnailImagePath());
			}
			property.setStatus(true);

			if (property.getPropertyId() == 0) {
				property.setCreatedDate(new Date());
				property.setCreatedBy(property.getUserId());
			} else {
				Property dbPropertyDetail = propertyDao.findById(savePropertyDto.getProperty().getPropertyId());
				property.setCreatedDate(dbPropertyDetail.getCreatedDate());
				property.setCreatedBy(dbPropertyDetail.getCreatedBy());
			}
			property.setModifiedBy(property.getUserId());
			property.setModifiedDate(new Date());

			User user = userDao.findById(property.getUserId());
			property.setUser(user);

			property.setPrice(property.getPrice().replaceAll(",", "").replace("$", ""));

			if (property.getPropertyDetails().getNoi() != null && !property.getPropertyDetails().getNoi().isEmpty()) {
				property.getPropertyDetails()
						.setNoi(property.getPropertyDetails().getNoi().replaceAll(",", "").replace("$", ""));
			}

			if (property.getPropertyDetails().getLotSize() != null
					&& !property.getPropertyDetails().getLotSize().isEmpty()) {
				property.getPropertyDetails()
						.setLotSize(property.getPropertyDetails().getLotSize().replaceAll(",", ""));
			}

			if (property.getPropertyDetails().getBuildingSize() != null
					&& !property.getPropertyDetails().getBuildingSize().isEmpty()) {
				property.getPropertyDetails()
						.setBuildingSize(property.getPropertyDetails().getBuildingSize().replaceAll(",", ""));
			}

			if (property.getPropertyDetails().getSpaceAvailable() != null
					&& !property.getPropertyDetails().getSpaceAvailable().isEmpty()) {
				property.getPropertyDetails()
						.setSpaceAvailable(property.getPropertyDetails().getSpaceAvailable().replaceAll(",", ""));
			}
			
			property.setPropertyType(propertyTypeDao.findById(property.getPropertyTypeId()));

			PropertyDetails propertyDetails = property.getPropertyDetails();
			propertyDetails.setProperty(property);

			String subType = property.getPropertySubTypeId().substring(1, property.getPropertySubTypeId().length() - 1);
			property.setSubTypeId(subType);
			
			///////////
			property.setStateData(stateDao.findById(property.getStateId()));
			

			// Getting the coordinates of the property
			Map<String, String> coords = new LocationUtil().getCoordinates(property);
			if (!coords.isEmpty()) {
				property.setLatitude(coords.get("lat"));
				property.setLongitude(coords.get("lon"));
			} else {
				property.setLatitude("0.00");
				property.setLongitude("0.00");
			}
			
			
			propertyDao.save(property);

			String attachments[][];
			if (propertyAttachments != null) {
				for (int i = 0; i < propertyAttachments.length; i++) {
					propertyAttachment = new PropertyAttachement();
					if (!editAttachment.isEmpty() && editAttachment != null) {
						String[] attachment = editAttachment.split(",");
						attachments = new String[attachment.length][3];
						for (int j = 0; j < attachment.length; j++) {
							attachments[j] = attachment[j].split("_");
							if (i == Integer.parseInt(attachments[j][2])) {
								propertyAttachment = propertyAttachmentDao
										.findById(Integer.parseInt(attachment[j].split("_")[0])).get();
								break;
							}
						}
					}
					fileName = new Date().getTime() + "_" + propertyAttachments[i].getOriginalFilename();
					propertyAttachment.setProperty(property);
					propertyAttachment.setStatus(true);
					if (propertyAttachment.getAttachementId() > 0) {
						FileUtil.deleteFile(propertyAttachment.getAttachementPath());
					}
					propertyAttachment.setOriginelAttachementName(propertyAttachments[i].getOriginalFilename());
					String path = FileUtil.createDir(property.getUserId(), "/property/");
					propertyAttachment.setAttachementPath(
							"assets/attachments/" + property.getUserId() + "/property/" + fileName);
					FileUtil.doUpload(propertyAttachments[i], path + "/" + fileName);
					if (propertyAttachment.getAttachementId() != 0) {
						propertyAttachment.setModifiedBy(property.getUserId());
						propertyAttachment.setModifiedDate(new Date());
					} else {
						propertyAttachment.setCreatedBy(property.getUserId());
						propertyAttachment.setCreatedDate(new Date());
					}
					propertyAttachmentDao.save(propertyAttachment);
				}
			}

			// Save the default property image
			if ((defaultImageName == null || defaultImageName.isEmpty()) && newDefaultImageDetail == null) {
				
			} else {
				this.saveDefaultPropertyImage(property, defaultImageName, newDefaultImageDetail);
			}
			


			if (propertyImages != null && propertyImages.length > 0) {
				for (int i = 0; i < propertyImages.length; i++) {
					propertyGallery = new PropertyGallery();
					if (editImage != null && !editImage.isEmpty()) {
						String[] images = editImage.split(",");
						for (int j = 0; j < images.length; j++) {
							String editImageArr[] = images[j].split("_");
							if (i == Integer.parseInt(editImageArr[2])) {
								propertyGallery = propertyGalleryDao.findById(Integer.parseInt(editImageArr[0])).get();
								break;
							}
						}
					}
					fileName = new Date().getTime() + propertyImages[i].getOriginalFilename();
					
					propertyGallery.setProperty(property);
					propertyGallery.setStatus(true);
					propertyGallery.setOriginelImageName(propertyImages[i].getOriginalFilename());
					
					//Deleting the property image
					if (propertyGallery.getGalleryId() > 0) {
						if (propertyGallery.getImagePath() != null && !propertyGallery.getImagePath().isEmpty()) {
							FileUtil.deleteFile(propertyGallery.getImagePath());
						}
						if (propertyGallery.getThumbnailImagePath() != null
								&& !propertyGallery.getThumbnailImagePath().isEmpty()) {
							FileUtil.deleteFile(propertyGallery.getThumbnailImagePath());
						}
					}
					
					propertyGallery.setImagePath(Constant.FILE_PATH + property.getUserId() + "/property/" + fileName);
					propertyGallery.setThumbnailImagePath(Constant.FILE_PATH + property.getUserId() + "/property/thumbnail_"+ fileName);
					ImageUtil.imageIoWrite(propertyImages[i], fileName,FileUtil.createDir(property.getUserId(), "/property/"));
					ImageUtil.imageIoWrite(propertyImages[i], "thumbnail_" + fileName,FileUtil.createDir(property.getUserId(), "/property/"));
					
					if (propertyImages[i].getOriginalFilename().equals(defaultImageName)) {
						propertyGallery.setDefaultImage(true);
						property.setDefaultImagePath(propertyGallery.getImagePath());
						property.setThumbnailImagePath(propertyGallery.getThumbnailImagePath());
						propertyDao.save(property);
					}
					if (propertyGallery.getGalleryId() != 0) {
						propertyGallery.setModifiedBy(property.getUserId());
						propertyGallery.setModifiedDate(new Date());
					} else {
						propertyGallery.setCreatedBy(property.getUserId());
						propertyGallery.setCreatedDate(new Date());
					}
					propertyGalleryDao.save(propertyGallery);
				}
			}
		} catch (Exception e) {
			log.info("Error in create property :: save() method.", e);
			return Constant.FAILURE;
		}
		log.info("PropertyServiceImpl :: save() method end.");
		return Constant.SUCCESS;

	}

	/**
	 * This method is used to save default property image
	 * 
	 * @author niteshD
	 * @param property - save property details
	 * @param defaultImageName - save default image
	 * @param newDefaultImageDetail - save new default image
	 */
	private void saveDefaultPropertyImage(Property property, String defaultImageName,
			PropertyGallery newDefaultImageDetail) {
		log.info("PropertyServiceImpl :: saveDefaultPropertyImage() method start.");
		
		// Remove the previous default property image.
		PropertyGallery propertyGalleryDetail = propertyGalleryDao
				.getPropertyGalleryByPropertyIdAndDefaultImage(property.getPropertyId(), true);
		if (propertyGalleryDetail != null) {
			propertyGalleryDetail.setDefaultImage(false);
			propertyGalleryDao.save(propertyGalleryDetail);
		}

		// Save the new default property image
		if (newDefaultImageDetail != null) {
			newDefaultImageDetail.setDefaultImage(true);
			newDefaultImageDetail.setProperty(property);
			propertyGalleryDao.save(newDefaultImageDetail);
		}
		log.info("PropertyServiceImpl :: saveDefaultPropertyImage() method end.");
	}

	/**
	 * Method to get property by property id
	 * @author karunaS
	 * @date April 01, 2019
	 * @param id - find based on id
	 * @return property entity
	 *
	 */
	@Override
	public Property findPropertyById(int id) {
		log.info("PropertyServiceImpl :: findAll() method executed.");
		return propertyDao.findById(id);
	}

    /**
     * This method is use for get the property data by propertyId
     * 
     * @date April 02, 2019
     * @author karunaS
     * @param id- get the property data by property id
     * @return Property Dto 
     */
	@Override
	public PropertyDto findOne(int id) {
		Property property = propertyDao.findById(id);
		PropertyDto propertyDto = new PropertyDto();
		if (property != null) {
			propertyDto.setPropertyId(property.getPropertyId());
			propertyDto.setPropertyName(property.getPropertyName());
			propertyDto.setPrice(property.getPrice());
			propertyDto.setAddressOne(property.getAddressOne());
			propertyDto.setAddressTwo(property.getAddressTwo());
			propertyDto.setCity(property.getCity());
			propertyDto.setState(property.getState());
			propertyDto.setZipCode(property.getZipCode());
			propertyDto.setPublishProperty(property.isPublishProperty());
			propertyDto.setPropertyStatus(property.getPropertyStatus());
			propertyDto.setContactName(property.getContactName());
			propertyDto.setContactEmail(property.getContactEmail());
			propertyDto.setPhone(property.getPhone());
			propertyDto.setLatitude(property.getLatitude());
			propertyDto.setLongitude(property.getLongitude());
			propertyDto.setLeasePriceType(property.getLeasePriceType());
			propertyDto.setContactNameTwo(property.getContactNameTwo());
			propertyDto.setPhoneTwo(property.getPhoneTwo());
			propertyDto.setContactEmailTwo(property.getContactEmailTwo());
			propertyDto.setCompanyNameOne(property.getCompanyNameOne());
			propertyDto.setCompanyNameTwo(property.getCompanyNameTwo());
			
			if (property.getSubTypeId() != null && !property.getSubTypeId().isEmpty()) {
				String testString = property.getSubTypeId();

				if (testString != null && !testString.isEmpty()) {
					String str[] = testString.split(",");
					int[] typeIdArr = new int[str.length];
					for (int i = 0; i < str.length; i++) {
						typeIdArr[i] = Integer.parseInt(str[i].trim());
					}
					if (typeIdArr.length > 0) {
						propertyDto.setSubTypeId(typeIdArr);
					}
				}
			}
			for (PropertyGallery propertyGallery1 : propertyGalleryDao
					.getPropertyGalleryByPropertyId(property.getPropertyId())) {
				if (propertyGallery1.isDefaultImage()) {
					propertyDto.setDefaultImagePath(propertyGallery1.getImagePath());
					propertyDto.setThumbnailImagePath(propertyGallery1.getThumbnailImagePath());
				}
			}
			propertyDto.setPropertyGallery(propertyGalleryDao.getPropertyGalleryByPropertyId(property.getPropertyId()));
			propertyDto.setPropertyAttachement(propertyAttachmentDao.getPropertyAttachmentByPropertyId(property.getPropertyId()));
			propertyDto.setStatus(property.isStatus());
			propertyDto.setPropertyType(property.getPropertyType());
			propertyDto.setPropertyDetails(property.getPropertyDetails());
			propertyDto.setStateData(property.getStateData());

		}
		log.info("UserServiceImpl :: findOne() method end.");
		return propertyDto;
	}

	/**
     * This method is use for delete the property by propertyId
     * 
     * @date April 02, 2019
     * @param id- delete the property data by property id
     * @author karunaS
     * @return string success message 
     */
	@Override
	public String delete(int id) {
		propertyDao.findById(id).setStatus(false);
		return Translator.toLocale("lang.delete.property");
	}


	/**
     * This method is used to get all property type list from the data base
     * 
     * @author KarunaS
     * @date April 03, 2019
     * @param null
     * @return ;list of PropertyTypeDto
     */
	@Override
	public List<PropertyTypeDto> getPropertyTypeList() {
		log.info("PropertyServiceImpl :: getPropertyTypeList() method started.");
		List<PropertyTypeDto> propertyTypeDto = new ArrayList<>();
		propertyTypeDao.findAllTypes().iterator()
				.forEachRemaining(property -> propertyTypeDto.add(property.toPropertyTypeDto()));
		return propertyTypeDto;
	}

	/**
     * This method is used to get all property Sub type list from the data base
     * 
     * @author KarunaS
     * @date April 04, 2019
     * @param typeId - find the data by the property type
     * @return list of PropertySubType
     */
	@Override
	public List<PropertySubType> getPropertySubTypeList(int typeId) {
		log.info("PropertyServiceImpl :: getPropertySubTypeList() method started.");
		List<PropertySubType> propertySubType = propertySubTypeDao.findByPropertyTypeId(typeId);
		return propertySubType;

	}

	/**
	 * upload property gallery
	 * 
	 * @date April 10, 2019
	 * @author karunaS
	 * @param property,request,propertylImage
	 * @return propertyGallery
	 */
	public PropertyGallery uploadMultiFiles(MultipartFile propertyImages, Property property) {
		log.info("UserServiceImpl :: updateDetails() method strated.");
		PropertyGallery propertyGallery = new PropertyGallery();
		if (propertyImages != null) {
			propertyGallery.setOriginelImageName("abc.jpg");
			propertyGallery.setStatus(true);
			propertyGallery.setDefaultImage(true);
		}
		log.info("UserServiceImpl :: updatePassword() method end.");
		return propertyGallery;
	}

	
	/**
	 * Method to find get all property list based on property type and sort type
	 * 
	 * @author VarunB
	 * @param sortDto
	 * @return list of PropertyDto
	 */
	@Override
	public List<PropertyDto> getPropertiesBySort(SortDto sortDto) {
		log.info("PropertyServiceImpl :: getPropertiesBySort() method executed.");
		Pageable sorted;
		if (sortDto.getSortType() != null && !sortDto.getSortType().isEmpty()
				&& sortDto.getSortType().equals("ascending")) {
			sorted = PageRequest.of(sortDto.getPageNo(), sortDto.getMaxElements(),
					Sort.by(sortDto.getSortCategory()).ascending());
		} else {
			sorted = PageRequest.of(sortDto.getPageNo(), sortDto.getMaxElements(),
					Sort.by(sortDto.getSortCategory()).descending());
		}
		List<PropertyDto> properties = new ArrayList<>();
		propertyDao.findSortedByStatus(sortDto.getPropertyStatus(), sortDto.getUserId(), sorted).iterator()
				.forEachRemaining(property -> properties.add(property.toPropertyDto()));
		log.info("PropertyServiceImpl :: getPropertiesBySort() method end.");
		return properties;
	}

	
	/**
     * Method to find get all property list based on property type, sort
     * category, sort type and page no
     * 
     * @author VarunB
     * @param SortDto sortDto
     * @return list of property by sortDto parameters
     */
	@Override
	public List<Property> getPropertiesByStatus(SortDto sortDto) {
		log.info("PropertyServiceImpl :: getPropertySubTypeList() method started.");
		List<Property> properties = new ArrayList<>();
		boolean status = true;
		User user = userDao.findById(sortDto.getUserId());
		PageRequest pageRequest = null;
		if (sortDto.getSortCategory() != null && !sortDto.getSortCategory().isEmpty()) {
			String str[] = sortDto.getSortCategory().split("-");
			sortDto.setSortCategory(str[0]);
			if (str[1].equalsIgnoreCase("asc")) {
				pageRequest = PageRequest.of(sortDto.getPageNo(), sortDto.getMaxElements(),
						Sort.by(sortDto.getSortCategory()).ascending());
			} else {
				pageRequest = PageRequest.of(sortDto.getPageNo(), sortDto.getMaxElements(),
						Sort.by(sortDto.getSortCategory()).descending());
			}
		}

		if (sortDto.getPropertyStatus() != null && !sortDto.getPropertyStatus().isEmpty()) {
			if (!sortDto.getPropertyStatus().equals("sale") && !sortDto.getPropertyStatus().equals("lease")) {
				boolean publishProperty = (sortDto.getPropertyStatus().equalsIgnoreCase("active")) ? true : false;
				properties = propertyDao.findByPublishProperty(publishProperty, sortDto.getUserId(), true, pageRequest);

				if (properties != null && !properties.isEmpty()) {
					properties.get(0).setTotalCount(
							propertyDao.countByUserAndPublishPropertyAndStatus(user, publishProperty, status));
					properties.get(0).setSaleCount(propertyDao.countByUserAndPropertyStatusAndStatusAndPublishProperty(
							user, "sale", status, publishProperty));
					properties.get(0).setLeaseCount(propertyDao.countByUserAndPropertyStatusAndStatusAndPublishProperty(
							user, "lease", status, publishProperty));
				}
			} else {
				properties = propertyDao.findByStatus(sortDto.getPropertyStatus(), sortDto.getUserId(), status,
						pageRequest);

				if (properties != null && properties.size() != 0) {
					properties.get(0).setTotalCount(propertyDao.countByUserAndPropertyStatusAndStatus(user,
							sortDto.getPropertyStatus(), status));
					properties.get(0)
							.setActiveCount(propertyDao.countByUserAndPublishPropertyAndStatusAndPropertyStatus(user,
									true, status, sortDto.getPropertyStatus()));
					properties.get(0).setDraftCount(propertyDao.countByUserAndPublishPropertyAndStatusAndPropertyStatus(
							user, false, status, sortDto.getPropertyStatus()));
				}
			}
		} else {
			properties = propertyDao.findByUser(sortDto.getUserId(), status, pageRequest);
			if (properties != null && properties.size() != 0) {
				properties.get(0).setTotalCount(propertyDao.countByUserAndStatus(user, status));
				properties.get(0)
						.setActiveCount(propertyDao.countByUserAndPublishPropertyAndStatus(user, true, status));
				properties.get(0)
						.setDraftCount(propertyDao.countByUserAndPublishPropertyAndStatus(user, false, status));
			}
		}
		log.info("PropertyServiceImpl :: getPropertySubTypeList() method end.");
		return properties;
	}

	/**
	 * Method to post property or save property as draft
	 * 
	 * @param property id -get the property data by property id
	 * @return success or failure message
	 * @author VarunB
	 */
	@Override
	public String postProperty(int id) {
		log.info("PropertyServiceImpl :: postProperty() method started.");
		Property property = propertyDao.findById(id);
		boolean publishProperty = (property.isPublishProperty()) ? false : true;
		property.setPublishProperty(publishProperty);
		property.setModifiedDate(new Date());
		property.setModifiedBy(property.getUserId());
		propertyDao.save(property);
		log.info("PropertyServiceImpl :: postProperty() method end.");
		return Constant.SUCCESS;
	}


	 /**
     * This method delete the property gallery by gallery id
     * 
     * @date April 26, 2019
     * @author VarunB
     * @param id - delete the gallery by id
     * @return success or failure message
     */
	@Override
	public String deleteGallery(int id) {
		PropertyGallery propertyGalleryDetail = propertyGalleryDao.findById(id).get();
		if (propertyGalleryDetail != null) {
			if (propertyGalleryDetail.getImagePath() != null && !propertyGalleryDetail.getImagePath().isEmpty()) {
				FileUtil.deleteFile(propertyGalleryDetail.getImagePath());
			}
			if (propertyGalleryDetail.getThumbnailImagePath() != null
					&& !propertyGalleryDetail.getThumbnailImagePath().isEmpty()) {
				FileUtil.deleteFile(propertyGalleryDetail.getThumbnailImagePath());
			}

			Property property = propertyGalleryDetail.getProperty();
			if (property.getPropertyId() != 0) {
				property.setModifiedBy(property.getUserId());
				property.setModifiedDate(new Date());
				propertyDao.save(property);
			}
			propertyGalleryDao.deleteById(id);
		}

		log.info("PropertyServiceImpl :: deleteGallery() method executed.");
		return Constant.SUCCESS;
	}


	 /**
     * This method is use for delete the property attachment by attachment id
     * 
     * @date April 26, 2019
     * @author VarunB
     *  @param delete the attachment by id
     * @return success 
     */
	@Override
	public String deleteAttachment(int id) {
		log.info("PropertyServiceImpl :: deleteAttachment() method started.");
		PropertyAttachement propertyAttachmentDetail = propertyAttachmentDao.findById(id).get();
		if (propertyAttachmentDetail != null) {
			if (propertyAttachmentDetail.getAttachementPath() != null
					&& !propertyAttachmentDetail.getAttachementPath().isEmpty()) {
				FileUtil.deleteFile(propertyAttachmentDetail.getAttachementPath());
			}

			Property property = propertyAttachmentDetail.getProperty();
			if (property.getPropertyId() != 0) {
				property.setModifiedBy(property.getUserId());
				property.setModifiedDate(new Date());
				propertyDao.save(property);
			}
			propertyAttachmentDao.deleteById(id);
		}

		log.info("PropertyServiceImpl :: deleteAttachment() method end.");
		return Constant.SUCCESS;
	}

	 /**
     * Method is Method to add property attachment description by id
     * 
     * @author VarunB
     * @param int attachmentId
     * @param String attachementDescription
     * @return success
     */
	@Override
	public String renameAttachment(int attachmentId, String attachementDescription) {
		log.info("PropertyServiceImpl :: renameAttachment() method started.");
		PropertyAttachement propertyAttachment = propertyAttachmentDao.findById(attachmentId).get();
		propertyAttachment.setAttachementDescription(attachementDescription);
		log.info("PropertyServiceImpl :: renameAttachment() method end.");
		return Constant.SUCCESS;
	}


	
	 /**
     * Method is used to find get all property type list by sale and lease
     * 
     * @author KarunaS
     * @date May 07, 2019
     * @param saleLeaseType
     * @return PropertyType list data
     */
    @Override
    public List<PropertyType> getPropertyTypeListBySaleLease(String saleLeaseType) {
        log.info("PropertyServiceImpl :: getPropertyTypeListBySaleLease() method started.");
        List<PropertyType> propertyType = new ArrayList<>();
        propertyType = propertyTypeDao.findBypropertyStatus(saleLeaseType);
        List<PropertyTypeDto> propertyTypeDto = new ArrayList<>();
//		List<PropertyType> propertyType = propertyTypeDao.findAllTypes();
		for(int i=0; i < propertyType.size(); i++){
			propertyTypeDto.add(propertyType.get(i).toPropertyTypeDto());
			propertyTypeDto.get(i).setPropertySubType(propertySubTypeDao.findByPropertyTypeId(propertyTypeDto.get(i).getTypeId()));
		}
        return propertyType;
    }

    /**
	 * This method is used for get the property type and sub type list
     * @author VarunB
     * @return  propertyTypeDto list
     */
	@Override
	public List<PropertyTypeDto> getPropertyTypeAndSubTypeList() {
		log.info("PropertyServiceImpl :: getPropertyTypeAndSubTypeList() method started.");
		List<PropertyTypeDto> propertyTypeDto = new ArrayList<>();
		List<PropertyType> propertyType = propertyTypeDao.findAllTypes();
		for(int i=0; i < propertyType.size(); i++){
			propertyTypeDto.add(propertyType.get(i).toPropertyTypeDto());
			propertyTypeDto.get(i).setPropertySubType(propertySubTypeDao.findByPropertyTypeId(propertyTypeDto.get(i).getTypeId()));
		}
		return propertyTypeDto;
	}
  
    /**
     * Method is used to find get all state list
     * 
     * @date June 15, 2019
     * @author karunaS
     * @return state dto
     */
    @Override
    public List<StateDto> getStateList() {
        log.info("PropertyServiceImpl :: getPropertyTypeList() method started.");
        List<StateDto> stateDto = new ArrayList<>();
        stateDao.findAllState().iterator()
                .forEachRemaining(state -> stateDto.add(state.toStateDto()));
        return stateDto;
    }
}
