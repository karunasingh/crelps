/**
 * 
 */
package com.crelps.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crelps.dao.MenuDao;
import com.crelps.dao.RoleDao;
import com.crelps.dao.SubMenuDao;
import com.crelps.dto.MenuDto;
import com.crelps.model.Menu;
import com.crelps.model.Role;
import com.crelps.model.SubMenu;
import com.crelps.service.RolePermissionService;

/**
 * Class Information - This class is user for the business logic
 * 
 * @author KarunaS
 * @version 1.0 - 27-March-2019
 */
@Transactional
@Service(value = "roleService")
public class RolePermissionServiceImpl implements RolePermissionService {

	private static final Logger log = LoggerFactory.getLogger(RolePermissionServiceImpl.class);

	@Autowired
	private MenuDao menuDao;

	@Autowired
	private SubMenuDao subMenuDao;

	@Autowired
	private RoleDao roleDao;

	/**
	 * Method is used to find all menu and sub menu based on role id
	 * 
	 * @param roleId
	 * @author karunaS
	 */
	@Override
	public List<MenuDto> getMenuList(int roleId) {
		log.info("RolePermissionServiceImpl :: findAll() method started.");
		Role roleDetail = roleDao.findById(roleId);
		List<Menu> menuList = menuDao.findByRole(roleDetail);
		List<MenuDto> menuDtoList = new ArrayList<>();
		try {
			for (Menu menu : menuList) {
				List<SubMenu> subMenuList = subMenuDao.findAll(menu.getMenuId(), true);
				MenuDto menuDto = new MenuDto();
				menuDto.setMenuId(menu.getMenuId());
				menuDto.setMenuName(menu.getMenuName());
				menuDto.setMenuUrl(menu.getMenuUrl());
				menuDto.setStatus(menu.isStatus());
				menuDto.setSubMenuList(subMenuList);
				menuDtoList.add(menuDto);
			}
		} catch (Exception e) {
			log.info("Error in UserServiceImpl :: findAll() method.", e);
		}
		log.info("RolePermissionServiceImpl :: findAll() method end.");
		return menuDtoList;

	}

}
