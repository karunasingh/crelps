/*
 * ===========================================================================
 * File Name UserService.java
 *
 * Created on 24-October-2018
 *
 * This code contains copyright information which is the proprietary property
 * of crelps. No part of this code may be reproduced, stored or transmitted
 * in any form without the prior written permission of crelps.
 *
 * Copyright (C) crelps. 2018
 * All rights reserved.
 *
 * Modification history:
 * $Log: UserService.java,v $
 * ===========================================================================
 */

package com.crelps.service;

import java.util.List;

import com.crelps.dto.UserDto;
import com.crelps.model.User;

/**
 * Class Information - This class is used for maintaining the controller
 *
 * @author VarunB
 * @version 1.0 - 11-March-2018
 */
public interface UserService {

    /**
     * This method is use for save the user in the data base
     * @author KarunaS
     * @param user -  save user details
     * @return UserDto
     */
    UserDto save(UserDto user);

    /**
     * This method is use for fin the all user list
     * @author KarunaS
     * @param null
     * @return UserDto
     */
    List<UserDto> findAll();

    /**
     * This method is use for find one user based on id
     * @author VarunB
     * @param id
     * @return UserDto
     */
    User findOne(int id);

    /**
     * This method find user by name
     * @author VarunB
     * @param userName - find user by name
     * @return UserDto
     */
    UserDto findOne(String username);
    
    /**
     * This method is use for verify the user email at registration time
     * @author VarunB
     * @param userName
     * @return string type message
     */
    String verifyEmail(String username);
    

    /**
     * TThis method is use for update the password based on user id
     * @author karunaS
     * @param userDto -  save the data
     * @return string type message
     */
    String updatePassword(UserDto dto);
    
    /**
     * This method is use for update the company logo based on company and user
     * @author VarunB
     * @param userName
     * @param user
     * @return UserDto
     */
    String updateDetails(User user);
    
    
    /**
     * This method is use for change the password based on user id
     * @author varunB
     * @param dto - save user dto type
     * @return string type message
     */
    String passwordChange(UserDto dto);
    
}
