/**
 * ===========================================================================
 * File Name UserServiceImpl.java
 *
 * Created on 12-March-2019
 *
 * This code contains copyright information which is the proprietary property
 * of crelps. No part of this code may be reproduced, stored or transmitted
 * in any form without the prior written permission of crelps.
 *
 * Copyright (C) crelps. 2019
 * All rights reserved.
 *
 * Modification history:
 * $Log: UserServiceImpl.java,v $
 * ===========================================================================
 */
package com.crelps.service.impl;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crelps.config.Translator;
import com.crelps.dao.RoleDao;
import com.crelps.dao.UserDao;
import com.crelps.dao.UserDetailsDao;
import com.crelps.dto.UserDto;
import com.crelps.exception.InactiveAccountException;
import com.crelps.model.User;
//import com.crelps.model.UserDetails;
import com.crelps.service.EmailService;
import com.crelps.service.UserService;

/**
 * Class Information - This class is used for service for implement the business
 * logic
 * 
 * @author VarunB
 * @version 1.0 - 6-March-2018
 */
@Transactional
@Service(value = "userService")
public class UserServiceImpl implements UserDetailsService, UserService {

	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private UserDao userDao;

	@Autowired
	private UserDetailsDao userDetailsDao;

	@Autowired
	private RoleDao roleDao;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private EmailService emailService;

	/**
	 * @author VarunB
	 * @date March 12, 2019
	 * @return UserDetails
	 * @param userId
	 * @description load the data for login
	 */
	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		log.info("UserServiceImpl :: loadUserByUsername() method started.");
		User user = userDao.findByUsername(userId);
		Set<GrantedAuthority> grantedAuthorities = getAuthorities(user);
		if (user == null) {
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		else if (!user.isVerifiedEmail() || !user.isStatus()) {
			try {
				throw new InactiveAccountException("Inactive User.");
			} catch (InactiveAccountException e) {
				log.error("Account is not active.", e);
				return null;
			}
		} else {
			log.info("UserServiceImpl :: loadUserByUsername() method end.");
			return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
					grantedAuthorities);
		}
	}

	/**
	 * @author VarunB
	 * @date March 12, 2019
	 * @return GrantedAuthority
	 * @param user
	 * @description generate the access token
	 */
	private Set<GrantedAuthority> getAuthorities(User user) {
		log.info("UserServiceImpl :: getAuthorities() method start.");
		Set<GrantedAuthority> authorities = new HashSet<>();
		authorities.add(new SimpleGrantedAuthority("ROLE_" + user.getRole().getRole().toUpperCase()));
		log.info("UserServiceImpl :: getAuthorities() method end.");
		return authorities;
	}

	/**
	 * @author KarunaS
	 * @date March 12, 2019
	 * @return UserDto
	 * @param userDto
	 * @description save the registered user data in data base
	 */
	@Override
	public UserDto save(UserDto userDto) {
		log.info("UserServiceImpl :: save() method start.");
		  User userWithDuplicateUsername = userDao.findByUsername(userDto.getUsername());
		try {
			if (userWithDuplicateUsername != null && userDto.getUserId() != userWithDuplicateUsername.getUserId()) {
				userDto.setIsDuplicate("Duplicate username");
			} else {
				User user = new User();
				user.setUsername(userDto.getUsername());
				user.setPassword(passwordEncoder.encode(userDto.getPassword()));
				user.setFirstName(userDto.getFirstName());
				user.setLastName(userDto.getLastName());
				user.setVerifiedEmail(false);
				user.setStatus(true);
				user.setCreatedDate(new Date());
				user.setCreatedBy(0);
				user.setModifiedBy(0);
				user.setRole(roleDao.findById(userDto.getRoleId()));
				userDao.save(user);
				userDto.setPassword(null);
				userDto.setUserId(user.getUserId());
				// send email to the user
				emailService.sendNewRegisterEmail(user);
			}
		} catch (Exception e) {
			log.error("Error in UserServiceImpl :: save() method.", e);
		}
		log.info("UserServiceImpl :: save() method end.");
		return userDto;
	}

	/**
	 * Method is used to find all
	 * 
	 * @author karunaS
	 */
	@Override
	public List<UserDto> findAll() {
		log.info("UserServiceImpl :: findAll() method started.");
		List<UserDto> users = new ArrayList<>();
		userDao.findAll().iterator().forEachRemaining(user -> users.add(user.toUserDto()));
		log.info("UserServiceImpl :: findAll() method end.");
		return users;
	}

	/**
	 * Methdo is used to find one record based one id
	 */
	@Override
	public User findOne(int id) {
		log.info("UserServiceImpl :: findAll() method executed.");
		return userDao.findById(id);
	}

	/**
	 * Find user by user name
	 * 
	 * @author VarunB
	 * @param username
	 * @return userDao
	 */
	@Override
	public UserDto findOne(String username) {
		log.info("UserServiceImpl :: findOne() method started.");
		User userDetail = userDao.findByUsername(username);
		UserDto userDto = new UserDto();
		if (userDetail != null) {
			userDto.setFirstName(userDetail.getFirstName());
			userDto.setLastName(userDetail.getLastName());
			userDto.setUsername(userDetail.getUsername());
			userDto.setUserId(userDetail.getUserId());
			userDto.setCreatedDate(userDetail.getCreatedDate());
			userDto.setVerifiedEmail(userDetail.isVerifiedEmail());
			userDto.setStatus(userDetail.isStatus());
			userDto.setCreatedBy(userDetail.getUserId());
			userDto.setModifiedDate(userDetail.getModifiedDate());
			userDto.setModifiedBy(userDetail.getUserId());
			userDto.setRoleId(userDetail.getRole().getRoleId());
			userDto.setRole(userDetail.getRole());
			userDto.setUserDetails(userDetail.getUserDetails());
			userDto.setLicenseNo(userDetail.getLicenseNo());
		}
		log.info("UserServiceImpl :: findOne() method end.");
		return userDto;
	}

	/**
	 * @author VarunB
	 * @date March 13, 2019
	 * @return Message
	 * @param username
	 * @description find user by name
	 */
	@Override
	public String verifyEmail(String username) {
		log.info("UserServiceImpl :: verifyEmail() method strated.");
		User user = userDao.findByUsername(new String(Base64.getDecoder().decode(username)));
		user.setVerifiedEmail(true);
		//user.setStatus(true);
		userDao.save(user);
		log.info("UserServiceImpl :: verifyEmail() method end.");
		return Translator.toLocale("lang.email.message");
	}

	/**
	 * @author KarunaS
	 * @date March 25, 2019
	 * @return Message
	 * @param username
	 * @description change the password
	 */
	@Override
	public String updatePassword(UserDto dto) {
		log.info("UserServiceImpl :: updatePassword() method strated.");
		User user = userDao.findByUsername(new String(Base64.getDecoder().decode(dto.getUsername())));
		user.setPassword(passwordEncoder.encode(dto.getPassword()));
		user.setModifiedDate(new Date());
		userDao.save(user);
		log.info("UserServiceImpl :: updatePassword() method end.");
		return Translator.toLocale("lang.update.password");
	}

	/**
	 * Method to update the user details
	 * 
	 * @author VarunB
	 * @date April 01, 2019
	 * @return Message
	 * @param username
	 */

	@Override
    public String updateDetails(User user) {
		log.info("UserServiceImpl :: updateDetails() method strated.");
		User updatedUser = userDao.findByUsername(user.getUsername());
		updatedUser.setUsername(user.getUsername());
		updatedUser.setFirstName(user.getFirstName());
		updatedUser.setLastName(user.getLastName());
		updatedUser.setLicenseNo(user.getLicenseNo());

		com.crelps.model.UserDetails userDetails = user.getUserDetails();
		com.crelps.model.UserDetails updatedUserDetails;
		if (updatedUser.getUserDetails() == null) {
			updatedUserDetails = userDetails;
		} else {
			updatedUserDetails = updatedUser.getUserDetails();
		}
		updatedUserDetails.setCreatedBy(updatedUser.getUserId());
		updatedUserDetails.setModifiedBy(updatedUser.getUserId());
		if (updatedUserDetails.getUserDetailsId() == 0) {
			updatedUserDetails.setCreatedDate(new Date());
		}
		updatedUserDetails.setModifiedDate(new Date());
		updatedUserDetails.setUser(updatedUser);
		updatedUserDetails.setPhoneNumber(userDetails.getPhoneNumber());
		updatedUserDetails.setCompanyName(userDetails.getCompanyName());
		userDetailsDao.save(updatedUserDetails);
		updatedUser.setUserDetails(updatedUserDetails);
		userDao.save(updatedUser);
		log.info("UserServiceImpl :: updatePassword() method end.");
		return Translator.toLocale("lang.update.details");
	}

	/**
	 * Method to change the password with user_id
	 * 
	 * @param userDto
	 * @return Message
	 * @author VarunB
	 */
	@Override
	public String passwordChange(UserDto dto) {
		log.info("UserServiceImpl :: passwordChange() method started.");
		User user = userDao.findById(dto.getUserId());
		if (!BCrypt.checkpw(dto.getOldPassword(), user.getPassword())) {
			return Translator.toLocale("lang.incorrect.old.password");
		} else {
			user.setPassword(passwordEncoder.encode(dto.getPassword()));
			user.setModifiedDate(new Date());
			userDao.save(user);
			log.info("UserServiceImpl :: passwordChange() method end.");
			return Translator.toLocale("lang.update.password");
		}
	}

}
