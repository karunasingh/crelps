/**
 * 
 */
package com.crelps.service;

import com.crelps.model.Billing;

/**
 * Class Information - This class is use for service methods
 * 
 * @author KarunaS
 * @version 1.0 - 24-May-2019
 */
public interface BillingService {

    /**
     * This method is use for save the billing details
     * @author KarunaS
     * @param billing - save the data in to data base
     * @return Billing entity
     */
    Billing save(Billing billing);
}
