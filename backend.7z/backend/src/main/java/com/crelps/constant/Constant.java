package com.crelps.constant;

/**
 * Class Information - This class is used for all constants
 *
 * @author KarunaS
 * @version 1.0 - 5-March-2018
 */
public class Constant {
    
    private Constant(){
        
    }
	
	public static final String OS_PATH;
	private static final String OS = System.getProperty("os.name").toLowerCase();
	private static final String WINDOWS_PATH = "D:/";
	private static final String LINUX_PATH = "/opt/";
	private static final String MAC_PATH = "/Library/";
	public static final String ATTACHMENTS_PATH;
	
	static {
       OS_PATH = getOsPath();
       ATTACHMENTS_PATH = getAttachmentPath();
	}
	

	public static final String ROLE_SUPER_ADMIN = "ROLE_ADMIN";

	public static final String ROLE_BROKER = "ROLE_BROKER";

	public static final String ROLE_OWNER = "ROLE_OWNER";
	
	public static final String DB_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	
	public static final String FILE_PATH = "assets/attachments/";

	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
	public static final String INCORRECT_OLD_PASSWORD= "Old Password is incorrect";
	public static final String GOOGLE_API_KEY = "AIzaSyD2_EN13Xykp0MtKHq6YDSLR0wAvVKG-Yw";
	public static final String GOOGLE_API_URL = "https://maps.googleapis.com/maps/api/geocode/json?address=";
	
	
	/**
     * To find base directory for images based on the OS.
     * 
     * @author niteshd
     * @return String os path.
     */
    private static String getOsPath() {
        String osPath;
        if (OS.indexOf("win") >= 0) {
            osPath = WINDOWS_PATH;
        } else if (OS.indexOf("mac") >= 0) {
            osPath = MAC_PATH;
        } else if (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") != 0) {
            osPath = LINUX_PATH;
        } else {
            osPath = "";
        }
        return osPath;
    }
    
    /**
     * To find base directory for images based on the OS.
     * 
     * @author niteshd
     * @return String os path.
     */
    private static String getAttachmentPath() {
        String attachmentPath;
        if (OS.indexOf("win") >= 0) {
        	attachmentPath = WINDOWS_PATH + "AQUA_PMS/newWoekspace/Angular/src/assets/";
        //    attachmentPath = WINDOWS_PATH + "CRELPS workspace1/Angular/src/assets/";
//        	attachmentPath = WINDOWS_PATH + "Workspace/Angular/src/assets/";
        } else if (OS.indexOf("mac") >= 0) {
            attachmentPath = MAC_PATH + "/crelps/assets/";
        } else if (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") != 0) {
            attachmentPath = LINUX_PATH + "/crelps/assets/";
        } else {
        	attachmentPath = "";
        }
        return attachmentPath;
    }
}
