package com.crelps.dao;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.Role;
/**
 * Class Information - This class is used for accessing the data related to role
 * @author KarunaS
 * @date May 12, 2019
 */
@Repository
public interface RoleDao extends JpaRepository<Role, Long> {
	/**
	 * @author KarunaS
	 * @date March 12, 2019
	 * @param roles
	 */
	@Query(value = "SELECT * FROM roles where role IN (:roles)", nativeQuery = true)
	Set<Role> find(@Param("roles") List<String> roles);

	/**
	 * @author KarunaS
	 * @date March 19, 2019
	 * @param roleId
	 * @description fetch role data
	 */
	//@Query(value = "SELECT * FROM roles r where r.role_id = :roleId", nativeQuery = true)
	@Query(value = "SELECT r.role_id, r.role,r.description, r.status FROM roles r where r.role_id = :roleId", nativeQuery = true)
	Role findById(@Param("roleId") int roleId);

}
