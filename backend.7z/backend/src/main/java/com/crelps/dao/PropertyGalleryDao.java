/**
 * 
 */
package com.crelps.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.PropertyGallery;

/**
 * Class Information - This class is user for fetch the menu list from the data
 * base
 * 
 * @author VarunB
 * @version 1.0 - 20-April-2019
 */

@Repository
public interface PropertyGalleryDao extends JpaRepository<PropertyGallery, Integer> {

    /**
     * Method is used to delete the gallery
     * 
     * @author VarunB
     * @param propertyId
     * @param pageable
     * @return gallery data
     */
	@Query(value = "DELETE FROM property_gallery p where p.property_id = :propertyId", nativeQuery = true)
	PropertyGallery deletePropertyGalleryByPropertyId(@Param("propertyId") int propertyId);

	 /**
     * Method is used to find the gallery list
     * 
     * @author VarunB
     * @param propertyId
     * @param pageable
     * @return list of gallery
     */
	@Query(value = "SELECT * FROM property_gallery p where p.property_id = :propertyId", nativeQuery = true)
	List<PropertyGallery> getPropertyGalleryByPropertyId(@Param("propertyId") int propertyId);
	
	 /**
     * Method is used to find default image
     * 
     * @author VarunB
     * @param propertyId
     * @param defaultImage
     * @return default image
     */
	@Query(value = "SELECT * FROM property_gallery p where p.property_id = :propertyId AND default_image = :defaultImage", nativeQuery = true)
	PropertyGallery getPropertyGalleryByPropertyIdAndDefaultImage(@Param("propertyId") int propertyId, @Param("defaultImage") boolean defaultImage);

}
