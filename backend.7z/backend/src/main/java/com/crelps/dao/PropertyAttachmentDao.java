package com.crelps.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.PropertyAttachement;

/**
 * Class Information - This class is user for fetch the menu list from the data
 * base
 * 
 * @author VarunB
 * @version 1.0 - 22-April-2019
 */

@Repository
public interface PropertyAttachmentDao extends JpaRepository<PropertyAttachement, Integer> {

    /**
     * Method is used to find the user list based on status and pagination
     * 
     * @author varunB
     * @param propertyId
     * @return attachement list
     */
	@Query(value = "SELECT * FROM property_attachement p where p.property_id = :propertyId", nativeQuery = true)
	List<PropertyAttachement> getPropertyAttachmentByPropertyId(@Param("propertyId") int propertyId);

}
