/**
 * 
 */
package com.crelps.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.crelps.model.State;

/**
 * Class Information - This class is use for to connect the data base query
 * 
 * @author KarunaS
 * @version 1.0 - 15-June-2019
 */
@Repository
public interface StateDao extends JpaRepository<State, Integer>{

    /**
     * Method to find get all state list based on status
     * 
     * @author KarunaS
     * @param status
     * @return list of state
     */
    @Query(value = "SELECT * FROM state s where s.status=1", nativeQuery = true)
    List<State> findAllState();

    
    /**
     * Method to find get all state list based on status
     * 
     * @author KarunaS
     * @param status
     * @return list of state
     */
    State findById(int id);
    //@Query(value = "SELECT * FROM property_types r where r.type_id = :id", nativeQuery = true)
    //State findById(@Param("id") int id);


}
