
package com.crelps.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.Menu;
import com.crelps.model.Role;

/**
 * Class Information - This class is user for fetch the menu list from the data
 * base
 * 
 * @author KarunaS
 * @version 1.0 - 28-March-2019
 */
@Repository
public interface MenuDao extends JpaRepository<Menu, Long> {

    /**
     * Method is used to get the list of menus
     * 
     * @author KarunaS
     * @return manu list
     */
	List<Menu> findByRole(@Param("menuDetail") Role menuDetail);
}
