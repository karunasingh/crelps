package com.crelps.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crelps.model.UserDetails;

/**
 * Class Information - This class is user for fetch the user details
 * @author varunB
 *
 */
public interface UserDetailsDao extends JpaRepository<UserDetails, Integer> {

}
