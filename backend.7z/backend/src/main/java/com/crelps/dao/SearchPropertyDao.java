/**
 * 
 */
package com.crelps.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.Property;

/**
 * Class Information - This class is used for accessing the data related to search list
 * @author KarunaS
 * @date May 12, 2019
 */
@Repository
public interface SearchPropertyDao extends JpaRepository<Property, Integer> {
    
    /**
     * This query use for call store procedure with arguments
     * @author VarunB
     * @param address
     * @param propertyStatus
     * @param propertyType
     * @description fetch role data
     */
	@Query(nativeQuery = true, value = "call getProperties(:propertyType, :propertyStatus, :address)")
	List<Property> findByProperties(@Param("propertyType") int propertyType,
			@Param("propertyStatus") String propertyStatus, @Param("address") String address);
	
	/**
	 * This query use for call store procedure with arguments
	 * 
	 * @param propertyTypeId
	 * @param propertyStatus
	 * @param searchFieldVal
	 * @param city
	 * @param state
	 * @param zipcode
	 * @param tenancy
	 * @param minCapRate
	 * @param maxCapRate
	 * @param minLotSize
	 * @param maxLotSize
	 * @param minSalePrice
	 * @param maxSalePrice
	 * @param minYearBuilt
	 * @param maxYearBuilt
	 * @param subTypeId
	 * @param minBuildingSize
	 * @param maxBuildingSize
	 * @return ApiResponse
	 * @author VarunB
	 */
	@Query(nativeQuery = true, value = "call getDetailedSearchProperties(:propertyStatus, :searchFieldVal, :city, :state, :zipcode, :tenancy, :minCapRate, :maxCapRate, :minLotSize, :maxLotSize, :minSalePrice, :maxSalePrice, :minYearBuilt, :maxYearBuilt, :subTypeId, :minBuildingSize, :maxBuildingSize)")
	List<Property> findSaleProperties(@Param("propertyStatus") String propertyStatus,  @Param("searchFieldVal") String searchFieldVal,  @Param("city") String city,  @Param("state") int state,  @Param("zipcode") String zipcode,  @Param("tenancy") String tenancy,  @Param("minCapRate") int minCapRate,  @Param("maxCapRate") int maxCapRate,  @Param("minLotSize") int minLotSize,  @Param("maxLotSize")int maxLotSize,  @Param("minSalePrice")int minSalePrice,  @Param("maxSalePrice") int maxSalePrice,  @Param("minYearBuilt") int minYearBuilt,  @Param("maxYearBuilt")int maxYearBuilt,  @Param("subTypeId") String subTypeId,  @Param("minBuildingSize") int minBuildingSize,  @Param("maxBuildingSize") int maxBuildingSize);
	
}
