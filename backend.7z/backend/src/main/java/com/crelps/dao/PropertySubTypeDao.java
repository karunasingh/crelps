/**
 * 
 */
package com.crelps.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.PropertySubType;

/**
 * Class Information - This class is user for fetch the menu list from the data
 * base
 * 
 * @author KarunaS
 * @version 1.0 - 03-April-2019
 */
@Repository
public interface PropertySubTypeDao extends JpaRepository<PropertySubType, Integer> {

    /**
     * Method to find get all property sub type list based on sub_type_id
     * 
     * @author KarunaS
     * @param sub_type_id
     * @return property sub type 
     */
	@Query(value = "SELECT * FROM property_sub_types r where r.sub_type_id = :id", nativeQuery = true)
	PropertySubType findById(@Param("id") int id);

	   /**
     * Method to find get all property property sub type list based on type_id
     * 
     * @author KarunaS
     * @param typeId
     * @return list of property sub type  by type id
     */
	@Query(value = "SELECT * FROM property_sub_types r where r.type_id = :typeId", nativeQuery = true)
	List<PropertySubType> findByPropertyTypeId(@Param("typeId") int typeId);

	   /**
     * Method to find get all property sub type propertySubTypeId
     * 
     * @author KarunaS
     * @param propertySubTypeId
     * @return  property sub type by name
     */
	@Query(value = "SELECT * FROM property_sub_types r where r.sub_type_name = :propertySubTypeId", nativeQuery = true)
	String findBySubTypeName(@Param("propertySubTypeId") String propertySubTypeId);

}
