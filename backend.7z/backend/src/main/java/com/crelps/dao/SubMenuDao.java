package com.crelps.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.SubMenu;

/**
 * Class Information - This class is user for fetch the SubMenu list from the
 * data base
 * 
 * @author KarunaS
 * @version 1.0 - 28-March-2019
 */
@Repository
public interface SubMenuDao extends JpaRepository<SubMenu, Long> {

	/**
	 * @author KarunaS
	 * @date March 28, 2019
	 * @param roleId,
	 *            status
	 * @description fetch subMenus from the data base base on role is and status
	 */
	//@Query(value = "SELECT * FROM sub_menus s where s.menu_id = :menuId AND s.status=:status", nativeQuery = true)
	@Query(value = "SELECT s.sub_menu_id, s.sub_menu_name, s.menu_url, s.status, s.menu_id FROM sub_menus s where s.menu_id = :menuId AND s.status=:status", nativeQuery = true)
	List<SubMenu> findAll(@Param("menuId") int menuId, @Param("status") boolean TRUE);
}
