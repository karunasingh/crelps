/**
 * 
 */
package com.crelps.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.crelps.model.Settings;

/**
 * Class Information - This class is use for to connect the data base query
 * 
 * @author KarunaS
 * @version 1.0 - 20-May-2019
 */
@Repository
public interface SettingDao extends JpaRepository<Settings, Integer>{
    
    /**
     * This interface is user for find the setting data by setting id
     * @author KarunaS
     * @param settingsId
     * @description fetch setting  data
     */
    Settings findById(int settingsId);

}
