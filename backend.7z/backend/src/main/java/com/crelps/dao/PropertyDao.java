/**
 * 
 */
package com.crelps.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.Property;
import com.crelps.model.User;

/**
 * @author karunas
 */

@Repository
public interface PropertyDao extends JpaRepository<Property, Integer> {

	@Query(value = "SELECT * FROM properties p where p.property_id = :propertyId", nativeQuery = true)
	Property updatePropertyById(@Param("propertyId") int propertyId);

	/**
	 * Method to find get all property list based on user id according to paging
	 * 
	 * @author VarunB
	 * @param userId
	 * @param PageRequest
	 * @return list of properties by user id
	 */
	@Query(value = "SELECT * FROM properties p where p.user_id = :userId AND p.status = :status", nativeQuery = true)
	List<Property> findByUser(@Param("userId") int userId, @Param("status") boolean status, Pageable pageable);

	/**
	 * Method to find get all property list based on user id and propertyStatus
	 * according to paging
	 * 
	 * @author VarunB
	 * @param userId
	 * @param propertyStatus
	 * @param PageRequest
	 * @return list of properties by user id and propertyStatus according to
	 *         paging
	 */
	@Query(value = "SELECT * FROM properties p where p.property_status = :propertyStatus AND p.user_id = :userId", nativeQuery = true)
	List<Property> findSortedByStatus(@Param("propertyStatus") String propertyStatus, @Param("userId") int userId,
			Pageable pageable);

	/**
	 * Method to find get all property list based on user id and propertyStatus
	 * according to paging
	 * 
	 * @author VarunB
	 * @param userId
	 * @param propertyStatus
	 * @param PageRequest
	 * @return list of properties by user id and propertyStatus according to
	 *         paging
	 */
	@Query(value = "SELECT * FROM properties p where p.property_status = :propertyStatus AND p.user_id = :userId AND p.status = :status", nativeQuery = true)
	List<Property> findByStatus(@Param("propertyStatus") String propertyStatus, @Param("userId") int userId,
			@Param("status") boolean status, Pageable pageable);

	/**
	 * Method to find get all property list based on user id and publishProperty
	 * according to paging
	 * 
	 * @author VarunB
	 * @param userId
	 * @param publishProperty
	 * @param PageRequest
	 * @return list of properties by user id and publishProperty according to
	 *         paging
	 */
	@Query(value = "SELECT * FROM properties p where p.publish_property = :publishProperty AND p.user_id = :userId AND p.status = :status", nativeQuery = true)
	List<Property> findByPublishProperty(@Param("publishProperty") boolean publishProperty, @Param("userId") int userId, @Param("status") boolean status,
			Pageable pageable);

	/**
	 * Method to find get all property list based on user id and propertyStatus
	 * 
	 * @author VarunB
	 * @param userId
	 * @param propertyStatus
	 * @param publishProperty
	 * @return list of properties by user id and propertyStatus
	 */
	@Query(value = "SELECT * FROM properties p where p.property_status = :propertyStatus AND p.publish_property = :publishProperty AND p.user_id = :userId", nativeQuery = true)
	List<Property> findByPropertyStatusAndPublishProperty(@Param("propertyStatus") String propertyStatus,
			@Param("publishProperty") String publishProperty, @Param("userId") int userId);

	@Query(value = "SELECT * FROM properties p where p.property_id = :id", nativeQuery = true)
	Property findById(@Param("id") int id);

	long countByUserAndStatus(User user, boolean status);

	long countByUserAndPublishPropertyAndStatus(User user, boolean publishProperty, boolean status);

	long countByUserAndPropertyStatusAndStatus(User user, String porpertyStatus, boolean status);

	long countByUserAndPublishPropertyAndStatusAndPropertyStatus(User user, boolean publishPorperty, boolean status,
			String propertyStatus);

	long countByUserAndPropertyStatusAndStatusAndPublishProperty(User user, String propertyStatus, boolean status,
			boolean publishProperty);

	
	
}
