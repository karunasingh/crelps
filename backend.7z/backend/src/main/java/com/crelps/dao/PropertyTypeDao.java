/**
 * 
 */
package com.crelps.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.PropertyType;

/**
 * Class Information - This class is user for fetch the menu list from the data
 * base
 * 
 * @author KarunaS
 * @version 1.0 - 03-April-2019
 */

@Repository
public interface PropertyTypeDao extends JpaRepository<PropertyType, Integer> {

    /**
     * Method to find get all property list based on the type id
     * 
     * @author KarunaS
     * @param id
     */
	@Query(value = "SELECT * FROM property_types r where r.type_id = :id", nativeQuery = true)
	PropertyType findById(@Param("id") int id);

	   /**
     * Method to find get all property list based on status
     * 
     * @author KarunaS
     * @param status
     * @return list of property type
     */
	@Query(value = "SELECT * FROM property_types r where r.status=1", nativeQuery = true)
	List<PropertyType> findAllTypes();

	   /**
     * Method to find get all property type
     * 
     * @author KarunaS
     * @param propertyTypeId
     */
	PropertyType findByTypeName(String propertyTypeId);

	/**
     * Method to find get all property type list based on the sale and lease
     * 
     * @author KarunaS
     * @param saleLeaseType
     * @return list of property type
     */
    @Query(value = "SELECT * FROM property_types p where p.property_status like %:saleLeaseType%", nativeQuery = true)
    List<PropertyType> findBypropertyStatus(@Param("saleLeaseType") String saleLeaseType);
    
   
}
