package com.crelps.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.crelps.model.User;

/**
 * Class Information - This class is used for accessing the data related to users
 *
 * @author VarunB
 * @version 1.0 - 5-March-2018
 */
@Repository
public interface UserDao extends JpaRepository<User, Integer> {

    User findByUsername(String username);

    User findById(int userId);

    /**
     * Method is used to find the user list based on status and pagination
     * 
     * @author KarunaS
     * @param status
     * @param pageable
     * @return ApiResponse
     */
      @Query(value = "SELECT * FROM users u JOIN roles r ON u.role_id = r.role_id WHERE u.status = 1 AND r.role NOT IN ('ADMIN')", nativeQuery = true)
     List<User> findByStatus(Pageable pageable);
      
      /**
       * Method is used to count the owner and broker based on status 
       * 
       * @author KarunaS
       * @param status
       * @return long count of user
       */
     @Query(value = "SELECT count(*) FROM users u JOIN roles r ON u.role_id = r.role_id WHERE r.role NOT IN ('ADMIN') AND u.status = 1", nativeQuery = true)
     long countByStatus();
    
     /**
      * Method is used to count based on status and role
      * 
      * @author KarunaS
      * @param roleOwner
      * @param status
      * @return long count of user
      */
     @Query(value = "SELECT count(*) FROM users INNER JOIN roles ON users.role_id = roles.role_id WHERE roles.role = :roleOwner AND users.status = 1", nativeQuery = true)
     long countByStatusAndRole(@Param("roleOwner") String roleOwner);

     /**
      * Method is used to find the user list based on owner broker and pagination
      * 
      * @author KarunaS
      * @param role
      * @param status
      * @param pageable
      * @return user list
      */
     @Query(value = "SELECT * FROM users u JOIN roles r ON u.role_id = r.role_id WHERE r.role = :role AND u.status = 1 ", nativeQuery = true)
    List<User> findByRoleAndStatus(@Param("role") String role, Pageable pageable);


    
    


}
